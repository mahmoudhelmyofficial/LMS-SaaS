/**
 * LMS PWA Service Worker
 * IMPORTANT: Bump CACHE_VERSION on every production deploy to invalidate caches.
 */
const CACHE_VERSION = 'v3';
const STATIC_CACHE = 'lms-static-' + CACHE_VERSION;
const RUNTIME_CACHE = 'lms-runtime-' + CACHE_VERSION;

const PRECACHE_URLS = [
  '/',
  '/offline.html',
  '/css/site.css',
  '/css/responsive-mobile.css',
  '/css/brand-identity.css',
  '/js/site.js',
  '/js/pwa-register.js',
  '/favicon.ico',
  '/logo.png'
];

const STATIC_PREFIXES = ['/lib/', '/css/', '/js/', '/assets/', '/icons/', '/LMS.styles.css'];
const NETWORK_ONLY_PREFIXES = ['/hubs/', '/api/', '/manifest.json'];

function isStaticAsset(url) {
  const path = new URL(url, self.location.origin).pathname;
  return STATIC_PREFIXES.some(function (p) { return path.indexOf(p) === 0; });
}

function isNetworkOnly(url) {
  const path = new URL(url, self.location.origin).pathname;
  return NETWORK_ONLY_PREFIXES.some(function (p) { return path.indexOf(p) === 0; });
}

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(STATIC_CACHE).then(function (cache) {
      return cache.addAll(PRECACHE_URLS.map(function (u) { return new Request(u, { cache: 'reload' }); })).catch(function (err) {
        console.warn('SW precache addAll partial failure:', err);
      });
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('message', function (event) {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (key) {
        return key.startsWith('lms-') && key !== STATIC_CACHE && key !== RUNTIME_CACHE;
      }).map(function (key) { return caches.delete(key); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('push', function (event) {
  var data = { title: 'LMS', message: '', url: '/', tag: 'lms-notification', icon: '/icons/icon-192.png' };
  if (event.data) {
    try {
      var payload = event.data.json();
      data.title = payload.title || data.title;
      data.message = payload.message || data.message;
      data.url = payload.url || data.url;
      data.tag = payload.tag || data.tag;
      data.icon = payload.icon || data.icon;
    } catch (e) {
      data.message = event.data.text() || data.message;
    }
  }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.message,
      icon: data.icon,
      tag: data.tag,
      data: { url: data.url },
      requireInteraction: false,
      dir: 'rtl'
    })
  );
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var url = event.notification.data && event.notification.data.url ? event.notification.data.url : '/';
  var fullUrl = new URL(url, self.location.origin).href;
  if (fullUrl.indexOf(self.location.origin) !== 0) return;
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (clientList) {
      for (var i = 0; i < clientList.length; i++) {
        if (clientList[i].url.indexOf(self.location.origin) === 0 && 'focus' in clientList[i]) {
          clientList[i].navigate(fullUrl);
          return clientList[i].focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(fullUrl);
    })
  );
});

self.addEventListener('fetch', function (event) {
  if (event.request.method !== 'GET') return;

  var url = event.request.url;
  if (isNetworkOnly(url)) return;

  if (isStaticAsset(url)) {
    event.respondWith(
      caches.match(event.request).then(function (cached) {
        if (cached) return cached;
        return fetch(event.request).then(function (res) {
          if (res && res.status === 200 && res.type === 'basic') {
            var clone = res.clone();
            caches.open(RUNTIME_CACHE).then(function (cache) { return cache.put(event.request, clone); });
          }
          return res;
        });
      })
    );
    return;
  }

  event.respondWith(
    fetch(event.request).then(function (res) {
      if (res && res.status === 200 && res.type === 'basic') {
        var contentType = res.headers.get('content-type') || '';
        if (contentType.indexOf('text/html') !== -1) {
          var c = res.clone();
          caches.open(RUNTIME_CACHE).then(function (cache) { return cache.put(event.request, c); });
        }
      }
      return res;
    }).catch(function () {
      if (event.request.mode === 'navigate') {
        return caches.match('/offline.html').then(function (c) { return c || new Response('Offline', { status: 503, statusText: 'Service Unavailable' }); });
      }
      return caches.match(event.request);
    })
  );
});
