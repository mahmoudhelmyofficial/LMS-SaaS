/**
 * Instructor Book Forms Handler
 * Enterprise-level form submission handling with loading states and validation
 * Handles all book-related form submissions in the Instructor area
 */

(function() {
    'use strict';

    /**
     * Book Forms Manager
     * Manages form submissions, loading states, and user feedback
     */
    const BookFormsManager = {
        /**
         * Initialize all book forms
         */
        init: function() {
            this.initSubmitForReviewForms();
            this.initDeleteForms();
            this.initUnpublishForms();
            this.initRespondToReviewForms();
        },

        /**
         * Initialize Submit for Review forms
         */
        initSubmitForReviewForms: function() {
            const forms = document.querySelectorAll('#submitForReviewForm, #submitForReviewFormEdit');
            
            forms.forEach(form => {
                form.addEventListener('submit', (e) => {
                    // Show validation checklist before submission
                    const bookId = form.querySelector('input[name="id"]')?.value;
                    if (bookId) {
                        const confirmed = this.showValidationChecklistModal(bookId);
                        if (!confirmed) {
                            e.preventDefault();
                            return false;
                        }
                    }
                    
                    const button = form.querySelector('#submitForReviewBtn, #submitForReviewBtnEdit');
                    if (button) {
                        this.setButtonLoading(button, true);
                    }
                });
            });
        },

        /**
         * Initialize Delete forms
         * Note: Forms are identified by their action URL pattern
         */
        initDeleteForms: function() {
            // Find forms that contain delete-related buttons or have specific patterns
            const allForms = document.querySelectorAll('form[method="post"]');
            
            allForms.forEach(form => {
                const action = form.getAttribute('action') || '';
                const button = form.querySelector('button[type="submit"]');
                
                // Check if this is a delete form (contains "Delete" in action or button text)
                if (action.includes('Delete') || 
                    (button && button.textContent.includes('حذف'))) {
                    form.addEventListener('submit', (e) => {
                        if (button && !confirm('هل أنت متأكد من حذف هذا الكتاب؟ هذا الإجراء لا يمكن التراجع عنه.')) {
                            e.preventDefault();
                            return false;
                        }
                        
                        if (button) {
                            this.setButtonLoading(button, true);
                        }
                    });
                }
            });
        },

        /**
         * Initialize Unpublish forms
         */
        initUnpublishForms: function() {
            const allForms = document.querySelectorAll('form[method="post"]');
            
            allForms.forEach(form => {
                const action = form.getAttribute('action') || '';
                const button = form.querySelector('button[type="submit"]');
                
                // Check if this is an unpublish form
                if (action.includes('Unpublish') || 
                    (button && button.textContent.includes('إلغاء النشر'))) {
                    form.addEventListener('submit', (e) => {
                        if (button) {
                            this.setButtonLoading(button, true);
                        }
                    });
                }
            });
        },

        /**
         * Initialize Respond to Review forms
         */
        initRespondToReviewForms: function() {
            const allForms = document.querySelectorAll('form[method="post"]');
            
            allForms.forEach(form => {
                const action = form.getAttribute('action') || '';
                const responseInput = form.querySelector('input[name="response"]');
                
                // Check if this is a respond to review form
                if (action.includes('RespondToReview') || responseInput) {
                    form.addEventListener('submit', (e) => {
                        if (!responseInput || !responseInput.value.trim()) {
                            e.preventDefault();
                            alert('يرجى إدخال رد قبل الإرسال');
                            return false;
                        }
                        
                        const button = form.querySelector('button[type="submit"]');
                        if (button) {
                            this.setButtonLoading(button, true);
                        }
                    });
                }
            });
        },

        /**
         * Set button loading state
         * @param {HTMLElement} button - The button element
         * @param {boolean} loading - Whether to show loading state
         */
        setButtonLoading: function(button, loading) {
            if (!button) return;
            
            const textSpan = button.querySelector('.btn-text');
            const loadingSpan = button.querySelector('.btn-loading');
            
            if (loading) {
                button.disabled = true;
                if (textSpan) textSpan.classList.add('d-none');
                if (loadingSpan) loadingSpan.classList.remove('d-none');
            } else {
                button.disabled = false;
                if (textSpan) textSpan.classList.remove('d-none');
                if (loadingSpan) loadingSpan.classList.add('d-none');
            }
        },

        /**
         * Show validation checklist modal before submission
         * @param {string} bookId - The book ID
         * @returns {boolean} - Whether user confirmed submission
         */
        showValidationChecklistModal: function(bookId) {
            const requirements = [
                'صورة غلاف الكتاب',
                'ملف الكتاب (PDF, EPUB, MOBI, أو صوتي)',
                'وصف تفصيلي (50 حرف على الأقل)',
                'وصف مختصر (20 حرف على الأقل)',
                'تحديد السعر أو جعله مجاني'
            ];
            
            const message = 'قبل إرسال الكتاب للمراجعة، تأكد من إكمال المتطلبات التالية:\n\n' +
                          requirements.map((req, index) => `${index + 1}. ${req}`).join('\n') +
                          '\n\nملاحظة: إذا لم تكن جميع المتطلبات مكتملة، سيتم عرض رسالة خطأ بعد الإرسال.\n\n' +
                          'هل تريد المتابعة؟';
            
            return confirm(message);
        },

        /**
         * Show validation checklist (for future AJAX enhancement)
         * @param {number} bookId - The book ID
         */
        showValidationChecklist: async function(bookId) {
            try {
                // This could be enhanced to fetch validation status via AJAX
                // For now, we'll rely on server-side validation
                return true;
            } catch (error) {
                console.error('Error checking validation:', error);
                return false;
            }
        }
    };

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => BookFormsManager.init());
    } else {
        BookFormsManager.init();
    }

    // Export for global access if needed
    window.BookFormsManager = BookFormsManager;
})();

