/**
 * WEBUILDER LMS - Enterprise Secure Video Player
 * Netflix-quality player with canvas watermark and content protection
 * Supports: Local MP4, YouTube, Vimeo
 * @version 3.0.0
 */
var SecureVideoPlayer = (function () {
    'use strict';

    // ============================================================
    // PRIVATE STATE
    // ============================================================
    var _container = null;
    var _id = '';
    var _config = {};
    var _els = {};
    var _player = null;        // YT.Player or Vimeo.Player
    var _videoEl = null;       // HTML5 <video> for local
    var _isReady = false;
    var _isPlaying = false;
    var _isEnded = false;
    var _isSeeking = false;
    var _currentTime = 0;
    var _duration = 0;
    var _volume = 100;
    var _isMuted = false;
    var _speed = 1;
    var _lastTrackedSec = 0;
    var _sessionToken = null;
    var _deviceFingerprint = '';
    var _controlsTimeout = null;
    var _controlsVisible = true;
    var _progressInterval = null;
    var _heartbeatInterval = null;
    var _watermarkInterval = null;
    var _watermarkAnimFrame = null;
    var _retryCount = 0;
    var _maxRetries = 3;
    var _dropdownOpen = null;
    var _loadTimeoutId = null;

    function _clearLoadTimeout() {
        if (_loadTimeoutId) { clearTimeout(_loadTimeoutId); _loadTimeoutId = null; }
    }

    function _startLoadTimeout() {
        _clearLoadTimeout();
        _loadTimeoutId = setTimeout(function () {
            _loadTimeoutId = null;
            if (!_isReady) {
                _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
            }
        }, 15000);
    }

    // ============================================================
    // INIT
    // ============================================================
    function init(containerId) {
        _container = document.getElementById(containerId);
        if (!_container) return;

        _id = containerId;
        _readConfig();
        _cacheElements();
        if (!_requireElements()) {
            _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
            _startSession();
            return;
        }
        _generateFingerprint();
        _setupProtection();
        _setupControls();
        _setupKeyboard();
        _setupMobileGestures();

        _startWatermark();

        if (_config.provider === 'youtube') {
            if (!_config.videoId) {
                _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
                _startSession();
                return;
            }
            _initYouTube();
        } else if (_config.provider === 'vimeo') {
            if (!_config.videoId) {
                _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
                _startSession();
                return;
            }
            _initVimeo();
        } else {
            if (!_videoEl || !_config.videoUrl) {
                _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
                _startSession();
                return;
            }
            _initLocal();
        }

        _startSession();
        _startLoadTimeout();
    }

    // ============================================================
    // CONFIG
    // ============================================================
    function _readConfig() {
        var d = _container.dataset;
        _config = {
            provider: d.provider || 'local',
            videoUrl: d.videoUrl || '',
            videoId: d.videoId || '',
            videoType: d.videoType || 'video/mp4',
            lessonId: parseInt(d.lessonId, 10) || 0,
            studentName: d.studentName || '',
            studentEmail: d.studentEmail || '',
            studentPhone: d.studentPhone || '',
            watermarkText: d.watermarkText || '',
            progressUrl: d.progressUrl || '/Student/Learning/UpdateProgress'
        };
        // Ensure watermark text is never empty (fallback from name/email/phone or LMS)
        var w = (_config.watermarkText || '').trim();
        if (!w) {
            w = (_config.studentName || '').trim() || (_config.studentEmail || '').trim() || (_config.studentPhone || '').trim() || 'LMS';
        }
        _config.watermarkText = w;
        // Ensure local video URL is absolute so the browser can load it
        if (_config.provider === 'local' && _config.videoUrl && _config.videoUrl.indexOf('http') !== 0 && _config.videoUrl.indexOf('//') !== 0) {
            if (_config.videoUrl.charAt(0) === '/') {
                _config.videoUrl = (window.location.origin || '') + _config.videoUrl;
            }
        }
    }

    // ============================================================
    // ELEMENT CACHE
    // ============================================================
    function _cacheElements() {
        var $ = function (suffix) { return document.getElementById(_id + '_' + suffix); };
        _els = {
            frame: $('frame'),
            loader: $('loader'),
            overlay: $('overlay'),
            overlayText: $('overlayText'),
            overlaySubtext: $('overlaySubtext'),
            controls: $('controls'),
            progressBar: $('progressBar'),
            progressBuffered: $('progressBuffered'),
            progressFill: $('progressFill'),
            progressTooltip: $('progressTooltip'),
            playBtn: $('playBtn'),
            playIcon: $('playIcon'),
            muteBtn: $('muteBtn'),
            volumeIcon: $('volumeIcon'),
            volumeSlider: $('volumeSlider'),
            timeDisplay: $('timeDisplay'),
            speedBtn: $('speedBtn'),
            speedLabel: $('speedLabel'),
            speedMenu: $('speedMenu'),
            fullscreenBtn: $('fullscreenBtn'),
            fsIcon: $('fsIcon'),
            watermarkCanvas: $('watermark'),
            error: $('error'),
            errorMsg: $('errorMsg'),
            retryBtn: $('retryBtn'),
            recordingWarning: $('recordingWarning')
        };
        _videoEl = $('video');
    }

    // Required DOM elements for player UI; avoids black screen from silent init failure
    function _requireElements() {
        var required = [_els.frame, _els.overlay, _els.playBtn, _els.controls, _els.progressBar];
        for (var i = 0; i < required.length; i++) {
            if (!required[i]) return false;
        }
        return true;
    }

    // ============================================================
    // YOUTUBE
    // ============================================================
    function _initYouTube() {
        if (!window.YT || !window.YT.Player) {
            if (!document.getElementById('svp-yt-api')) {
                var tag = document.createElement('script');
                tag.id = 'svp-yt-api';
                tag.src = 'https://www.youtube.com/iframe_api';
                document.head.appendChild(tag);
            }
            window._svpYTQueue = window._svpYTQueue || [];
            window._svpYTQueue.push(_createYT);
            var oldCb = window.onYouTubeIframeAPIReady;
            window.onYouTubeIframeAPIReady = function () {
                if (oldCb) oldCb();
                while (window._svpYTQueue && window._svpYTQueue.length) window._svpYTQueue.shift()();
            };
        } else {
            _createYT();
        }
    }

    function _createYT() {
        _player = new YT.Player(_id + '_ytplayer', {
            videoId: _config.videoId,
            playerVars: {
                controls: 0, disablekb: 1, enablejsapi: 1, fs: 0,
                iv_load_policy: 3, modestbranding: 1, playsinline: 1,
                rel: 0, showinfo: 0, cc_load_policy: 0, origin: location.origin
            },
            events: {
                onReady: function () {
                    _clearLoadTimeout();
                    _isReady = true;
                    _duration = _player.getDuration() || 0;
                    _hideLoader();
                    _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0628\u062F\u0621 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629', '');
                    _startProgressLoop();
                },
                onStateChange: function (e) {
                    var s = e.data;
                    if (s === YT.PlayerState.PLAYING) {
                        _isPlaying = true; _isEnded = false;
                        _hideOverlay(); _setPlayingIcon(); _hideLoader();
                        _showControlsThenHide();
                    } else if (s === YT.PlayerState.PAUSED) {
                        _isPlaying = false;
                        if (!_isEnded) { _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629', ''); }
                        _setPausedIcon(); _hideLoader();
                        _showControlsPermanent();
                    } else if (s === YT.PlayerState.ENDED) {
                        _isPlaying = false; _isEnded = true;
                        _showOverlay('\uD83C\uDF89 \u062A\u0645 \u0627\u0644\u0627\u0646\u062A\u0647\u0627\u0621', '\u0627\u0646\u0642\u0631 \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629');
                        _setPausedIcon();
                        _trackProgress(Math.floor(_player.getDuration()), true);
                        _showControlsPermanent();
                    } else if (s === YT.PlayerState.BUFFERING) {
                        _showLoader();
                    }
                },
                onError: function () {
                    _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
                }
            }
        });
    }

    // ============================================================
    // VIMEO
    // ============================================================
    function _initVimeo() {
        if (!window.Vimeo) {
            var s = document.createElement('script');
            s.src = 'https://player.vimeo.com/api/player.js';
            s.onload = _createVimeo;
            document.head.appendChild(s);
        } else {
            _createVimeo();
        }
    }

    function _createVimeo() {
        var iframe = document.getElementById(_id + '_vimeo');
        if (!iframe) {
            _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
            return;
        }
        _player = new Vimeo.Player(iframe);
        _player.ready().then(function () {
            _clearLoadTimeout();
            _isReady = true;
            _player.getDuration().then(function (d) { _duration = d || 0; });
            _hideLoader();
            _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0628\u062F\u0621 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629', '');
            _startProgressLoop();
        }).catch(function () {
            _clearLoadTimeout();
            _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
        });
        _player.on('error', function () {
            _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
        });
        _player.on('play', function () {
            _isPlaying = true; _isEnded = false;
            _hideOverlay(); _setPlayingIcon(); _showControlsThenHide();
        });
        _player.on('pause', function () {
            _isPlaying = false;
            if (!_isEnded) _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629', '');
            _setPausedIcon(); _showControlsPermanent();
        });
        _player.on('ended', function () {
            _isPlaying = false; _isEnded = true;
            _showOverlay('\uD83C\uDF89 \u062A\u0645 \u0627\u0644\u0627\u0646\u062A\u0647\u0627\u0621', '\u0627\u0646\u0642\u0631 \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629');
            _setPausedIcon(); _showControlsPermanent();
            _player.getDuration().then(function (d) { _trackProgress(Math.floor(d), true); });
        });
        _player.on('bufferstart', function () { _showLoader(); });
        _player.on('bufferend', function () { _hideLoader(); });
    }

    // ============================================================
    // LOCAL VIDEO
    // ============================================================
    function _initLocal() {
        if (!_videoEl) return;
        // Use normalized URL from config (single source of truth; fixes proxy/relative URL issues)
        if (_config.videoUrl) {
            _videoEl.src = _config.videoUrl;
            _videoEl.load();
        }
        _videoEl.addEventListener('loadedmetadata', function () {
            _clearLoadTimeout();
            _isReady = true; _duration = _videoEl.duration || 0;
            _hideLoader();
            _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0628\u062F\u0621 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629', '');
        });
        _videoEl.addEventListener('play', function () {
            _isPlaying = true; _isEnded = false;
            _hideOverlay(); _setPlayingIcon(); _showControlsThenHide();
        });
        _videoEl.addEventListener('pause', function () {
            _isPlaying = false;
            if (!_isEnded) _showOverlay('\u0627\u0646\u0642\u0631 \u0644\u0644\u0645\u062A\u0627\u0628\u0639\u0629', '');
            _setPausedIcon(); _showControlsPermanent();
        });
        _videoEl.addEventListener('ended', function () {
            _isPlaying = false; _isEnded = true;
            _showOverlay('\uD83C\uDF89 \u062A\u0645 \u0627\u0644\u0627\u0646\u062A\u0647\u0627\u0621', '\u0627\u0646\u0642\u0631 \u0644\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629');
            _setPausedIcon(); _showControlsPermanent();
            _trackProgress(Math.floor(_videoEl.duration), true);
        });
        _videoEl.addEventListener('timeupdate', function () {
            _currentTime = _videoEl.currentTime;
            _duration = _videoEl.duration || 0;
            _updateProgressUI();
            _autoTrack();
        });
        _videoEl.addEventListener('progress', function () {
            if (_videoEl.buffered.length > 0 && _els.progressBuffered) {
                var end = _videoEl.buffered.end(_videoEl.buffered.length - 1);
                _els.progressBuffered.style.width = (_duration ? (end / _duration * 100) : 0) + '%';
            }
        });
        _videoEl.addEventListener('waiting', function () { _showLoader(); });
        _videoEl.addEventListener('canplay', function () { _hideLoader(); });
        _videoEl.addEventListener('error', function () {
            _showError('\u062D\u062F\u062B \u062E\u0637\u0623 \u0641\u064A \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648');
        });
    }

    // Progress loop for YT/Vimeo (they don't have timeupdate)
    function _startProgressLoop() {
        if (_progressInterval) clearInterval(_progressInterval);
        _progressInterval = setInterval(function () {
            if (!_isReady) return;
            if (_config.provider === 'youtube' && _player) {
                _currentTime = _player.getCurrentTime() || 0;
                _duration = _player.getDuration() || 0;
                _updateProgressUI();
                _autoTrack();
            } else if (_config.provider === 'vimeo' && _player) {
                Promise.all([_player.getCurrentTime(), _player.getDuration()]).then(function (v) {
                    _currentTime = v[0] || 0;
                    _duration = v[1] || 0;
                    _updateProgressUI();
                    _autoTrack();
                });
            }
        }, 250);
    }

    // ============================================================
    // UNIFIED PLAYBACK API
    // ============================================================
    function _toggle() {
        if (_config.provider === 'youtube') {
            if (!_player) return;
            _player.getPlayerState() === YT.PlayerState.PLAYING ? _player.pauseVideo() : _player.playVideo();
        } else if (_config.provider === 'vimeo') {
            if (!_player) return;
            _player.getPaused().then(function (p) { p ? _player.play() : _player.pause(); });
        } else {
            if (!_videoEl) return;
            _videoEl.paused ? _videoEl.play() : _videoEl.pause();
        }
    }

    function _seekTo(seconds) {
        seconds = Math.max(0, seconds);
        if (_config.provider === 'youtube' && _player) {
            _player.seekTo(seconds, true);
        } else if (_config.provider === 'vimeo' && _player) {
            _player.setCurrentTime(seconds);
        } else if (_videoEl) {
            _videoEl.currentTime = seconds;
        }
    }

    function _seekRelative(delta) {
        var target = _currentTime + delta;
        _seekTo(Math.min(target, _duration));
    }

    function _seekToPercent(pct) {
        _seekTo(pct * _duration);
    }

    function _setVolume(val) {
        _volume = Math.max(0, Math.min(100, val));
        _isMuted = _volume === 0;
        if (_config.provider === 'youtube' && _player) {
            _player.setVolume(_volume);
            _volume === 0 ? _player.mute() : _player.unMute();
        } else if (_config.provider === 'vimeo' && _player) {
            _player.setVolume(_volume / 100);
        } else if (_videoEl) {
            _videoEl.volume = _volume / 100;
            _videoEl.muted = _isMuted;
        }
        _els.volumeSlider.value = _volume;
        _updateVolIcon();
        try { localStorage.setItem('svp_volume', _volume); } catch (e) {}
    }

    function _toggleMute() {
        if (_isMuted) {
            var saved = 100;
            try { saved = parseInt(localStorage.getItem('svp_volume'), 10) || 100; } catch (e) {}
            _setVolume(saved || 100);
        } else {
            _setVolume(0);
        }
    }

    function _setSpeed(rate) {
        _speed = rate;
        if (_config.provider === 'youtube' && _player) {
            _player.setPlaybackRate(rate);
        } else if (_config.provider === 'vimeo' && _player) {
            _player.setPlaybackRate(rate);
        } else if (_videoEl) {
            _videoEl.playbackRate = rate;
        }
        _els.speedLabel.textContent = rate === 1 ? '1x' : rate + 'x';
        // Update active in dropdown
        var items = _els.speedMenu.querySelectorAll('.svp-dropdown-item');
        for (var i = 0; i < items.length; i++) {
            items[i].classList.toggle('active', parseFloat(items[i].dataset.speed) === rate);
        }
        try { localStorage.setItem('svp_speed', rate); } catch (e) {}
    }

    function _toggleFullscreen() {
        if (document.fullscreenElement || document.webkitFullscreenElement) {
            (document.exitFullscreen || document.webkitExitFullscreen).call(document);
        } else {
            (_container.requestFullscreen || _container.webkitRequestFullscreen).call(_container);
        }
    }

    // ============================================================
    // CONTROLS
    // ============================================================
    function _setupControls() {
        // Play button & overlay
        _els.playBtn.addEventListener('click', _toggle);
        _els.overlay.addEventListener('click', _toggle);

        // Progress bar seek
        _els.progressBar.addEventListener('click', function (e) {
            var rect = _els.progressBar.getBoundingClientRect();
            _seekToPercent((e.clientX - rect.left) / rect.width);
        });

        // Progress bar drag
        var dragging = false;
        _els.progressBar.addEventListener('mousedown', function (e) {
            dragging = true; _isSeeking = true;
            var rect = _els.progressBar.getBoundingClientRect();
            _seekToPercent((e.clientX - rect.left) / rect.width);
        });
        document.addEventListener('mousemove', function (e) {
            if (!dragging) return;
            var rect = _els.progressBar.getBoundingClientRect();
            var pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            _seekToPercent(pct);
        });
        document.addEventListener('mouseup', function () {
            if (dragging) { dragging = false; _isSeeking = false; }
        });

        // Progress tooltip on hover
        _els.progressBar.addEventListener('mousemove', function (e) {
            var rect = _els.progressBar.getBoundingClientRect();
            var pct = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
            var time = pct * _duration;
            _els.progressTooltip.textContent = _formatTime(time);
            _els.progressTooltip.style.left = (pct * 100) + '%';
            _els.progressTooltip.classList.add('visible');
        });
        _els.progressBar.addEventListener('mouseleave', function () {
            _els.progressTooltip.classList.remove('visible');
        });

        // Volume
        _els.muteBtn.addEventListener('click', _toggleMute);
        _els.volumeSlider.addEventListener('input', function () { _setVolume(parseInt(this.value, 10)); });

        // Restore saved volume
        try {
            var savedVol = localStorage.getItem('svp_volume');
            if (savedVol !== null) _setVolume(parseInt(savedVol, 10));
        } catch (e) {}

        // Speed dropdown
        _els.speedBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            _toggleDropdown(_els.speedMenu);
        });
        var speedItems = _els.speedMenu.querySelectorAll('.svp-dropdown-item');
        for (var i = 0; i < speedItems.length; i++) {
            speedItems[i].addEventListener('click', function (e) {
                e.stopPropagation();
                _setSpeed(parseFloat(this.dataset.speed));
                _closeDropdowns();
            });
        }

        // Restore saved speed
        try {
            var savedSpeed = localStorage.getItem('svp_speed');
            if (savedSpeed !== null) _setSpeed(parseFloat(savedSpeed));
        } catch (e) {}

        // Fullscreen
        _els.fullscreenBtn.addEventListener('click', _toggleFullscreen);
        document.addEventListener('fullscreenchange', _updateFsIcon);
        document.addEventListener('webkitfullscreenchange', _updateFsIcon);

        // Close dropdowns on outside click
        document.addEventListener('click', _closeDropdowns);

        // Auto-hide controls
        _container.addEventListener('mousemove', _showControlsThenHide);
        _container.addEventListener('touchstart', function () {
            if (_controlsVisible && _isPlaying) _hideControls();
            else _showControlsThenHide();
        }, { passive: true });

        // Error retry
        if (_els.retryBtn) {
            _els.retryBtn.addEventListener('click', function () {
                _hideError();
                _retryCount++;
                if (_retryCount > _maxRetries) {
                    _showError('\u0627\u062A\u0635\u0644 \u0628\u0627\u0644\u062F\u0639\u0645 \u0627\u0644\u0641\u0646\u064A');
                    return;
                }
                if (_config.provider === 'youtube') _initYouTube();
                else if (_config.provider === 'vimeo') _initVimeo();
                else if (_videoEl) { _videoEl.load(); }
            });
        }
    }

    // ============================================================
    // KEYBOARD
    // ============================================================
    function _setupKeyboard() {
        document.addEventListener('keydown', function (e) {
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.isContentEditable) return;
            var handled = true;
            switch (e.key) {
                case ' ': case 'k': case 'K': _toggle(); break;
                case 'f': case 'F': _toggleFullscreen(); break;
                case 'm': case 'M': _toggleMute(); break;
                case 'ArrowLeft': _seekRelative(-10); break;
                case 'ArrowRight': _seekRelative(10); break;
                case 'ArrowUp': _setVolume(_volume + 10); break;
                case 'ArrowDown': _setVolume(_volume - 10); break;
                default: handled = false;
            }
            if (handled) e.preventDefault();
        });
    }

    // ============================================================
    // MOBILE GESTURES
    // ============================================================
    function _setupMobileGestures() {
        var lastTap = 0;
        var tapTimeout = null;
        _container.addEventListener('touchend', function (e) {
            if (e.target.closest('.svp-controls') || e.target.closest('.svp-overlay') || e.target.closest('.svp-btn')) return;
            var now = Date.now();
            if (now - lastTap < 300) {
                clearTimeout(tapTimeout);
                var rect = _container.getBoundingClientRect();
                var x = e.changedTouches[0].clientX - rect.left;
                if (x < rect.width / 3) _seekRelative(-10);
                else if (x > rect.width * 2 / 3) _seekRelative(10);
                else _toggleFullscreen();
                lastTap = 0;
            } else {
                lastTap = now;
                tapTimeout = setTimeout(function () { lastTap = 0; }, 300);
            }
        }, { passive: true });
    }

    // ============================================================
    // CANVAS WATERMARK
    // ============================================================
    function _startWatermark() {
        var canvas = _els.watermarkCanvas;
        if (!canvas) return;
        var text = (_config.watermarkText || _config.studentName || _config.studentEmail || 'LMS').trim();
        if (!text) text = 'LMS';
        var ctx = canvas.getContext('2d');
        if (!ctx) return;

        var positions = [
            { x: 0.08, y: 0.12 }, { x: 0.65, y: 0.15 }, { x: 0.1, y: 0.5 },
            { x: 0.6, y: 0.55 }, { x: 0.08, y: 0.85 }, { x: 0.55, y: 0.82 },
            { x: 0.35, y: 0.35 }, { x: 0.3, y: 0.7 }
        ];
        var posIdx = 0;

        function resize() {
            var rect = _container.getBoundingClientRect();
            canvas.width = rect.width;
            canvas.height = rect.height;
        }

        function draw() {
            resize();
            ctx.clearRect(0, 0, canvas.width, canvas.height);

            // Diagonal grid watermark (very subtle)
            ctx.save();
            ctx.globalAlpha = 0.03;
            ctx.fillStyle = '#ffffff';
            ctx.font = '14px "Segoe UI", sans-serif';
            ctx.rotate(-0.35);
            for (var gy = -canvas.height; gy < canvas.height * 2; gy += 120) {
                for (var gx = -canvas.width; gx < canvas.width * 2; gx += 350) {
                    ctx.fillText(text, gx, gy);
                }
            }
            ctx.restore();

            // Primary floating watermark
            var pos = positions[posIdx];
            var x = pos.x * canvas.width;
            var y = pos.y * canvas.height;

            ctx.save();
            ctx.globalAlpha = 0.15;
            ctx.fillStyle = '#ffffff';
            ctx.font = '600 15px "Cairo", "Segoe UI", sans-serif';
            ctx.textBaseline = 'middle';

            // Background pill
            var metrics = ctx.measureText(text);
            var pad = 12;
            var pillW = metrics.width + pad * 2;
            var pillH = 30;
            ctx.globalAlpha = 0.08;
            ctx.beginPath();
            _roundRect(ctx, x - pad, y - pillH / 2, pillW, pillH, 15);
            ctx.fill();

            // Text
            ctx.globalAlpha = 0.15;
            ctx.fillText(text, x, y);
            ctx.restore();

            _watermarkAnimFrame = requestAnimationFrame(function () {
                // Keep redrawing to survive DOM manipulation
                setTimeout(draw, 100);
            });
        }

        draw();

        // Rotate position every 8 seconds
        _watermarkInterval = setInterval(function () {
            posIdx = (posIdx + 1) % positions.length;
        }, 8000);

        window.addEventListener('resize', resize);
        document.addEventListener('fullscreenchange', function () { setTimeout(resize, 100); });
    }

    function _roundRect(ctx, x, y, w, h, r) {
        ctx.moveTo(x + r, y);
        ctx.lineTo(x + w - r, y);
        ctx.quadraticCurveTo(x + w, y, x + w, y + r);
        ctx.lineTo(x + w, y + h - r);
        ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
        ctx.lineTo(x + r, y + h);
        ctx.quadraticCurveTo(x, y + h, x, y + h - r);
        ctx.lineTo(x, y + r);
        ctx.quadraticCurveTo(x, y, x + r, y);
        ctx.closePath();
    }

    // ============================================================
    // PROTECTION
    // ============================================================
    function _setupProtection() {
        // Right-click
        _container.addEventListener('contextmenu', function (e) {
            e.preventDefault();
            _reportSuspicious('CONTEXT_MENU', 'Right-click blocked', 10);
        });

        // Block screenshot shortcuts
        document.addEventListener('keydown', function (e) {
            if (e.key === 'PrintScreen') {
                e.preventDefault();
                try { navigator.clipboard.writeText(''); } catch (ex) {}
                _reportSuspicious('PRINTSCREEN', 'PrintScreen key blocked', 50);
            }
            if (e.ctrlKey && e.key === 'p') { e.preventDefault(); }
            if (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) {
                // Don't block globally — just report
                _reportSuspicious('DEVTOOLS_SHORTCUT', 'DevTools shortcut used', 30);
            }
        });

        // Override getDisplayMedia
        if (navigator.mediaDevices && navigator.mediaDevices.getDisplayMedia) {
            var orig = navigator.mediaDevices.getDisplayMedia.bind(navigator.mediaDevices);
            navigator.mediaDevices.getDisplayMedia = function (c) {
                _reportSuspicious('SCREEN_CAPTURE', 'Screen capture attempted', 90);
                _showRecordingWarning();
                _pauseVideo();
                return orig(c).then(function (stream) {
                    stream.getVideoTracks().forEach(function (track) {
                        track.addEventListener('ended', function () { _hideRecordingWarning(); });
                    });
                    return stream;
                }).catch(function (err) {
                    _hideRecordingWarning();
                    throw err;
                });
            };
        }

        // Disable PiP
        if (_videoEl) {
            _videoEl.disablePictureInPicture = true;
            _videoEl.disableRemotePlayback = true;
        }

        // Prevent drag
        _container.addEventListener('dragstart', function (e) { e.preventDefault(); });

        // Print protection
        window.addEventListener('beforeprint', function () {
            _container.style.visibility = 'hidden';
        });
        window.addEventListener('afterprint', function () {
            _container.style.visibility = 'visible';
        });
    }

    // ============================================================
    // SESSION MANAGEMENT
    // ============================================================
    function _startSession() {
        if (!_config.lessonId) return;
        var info = _getDeviceInfo();
        _apiPost('/api/secure-video/session/start', {
            lessonId: _config.lessonId,
            deviceFingerprint: _deviceFingerprint,
            deviceType: info.deviceType,
            browserName: info.browser,
            operatingSystem: info.os
        }).then(function (res) {
            if (res && res.success) {
                _sessionToken = res.sessionToken;
                _startHeartbeat();
            }
        }).catch(function () {});

        // End session on page leave
        window.addEventListener('beforeunload', function () {
            if (_sessionToken) {
                var data = JSON.stringify({ sessionToken: _sessionToken, reason: 'PageUnload' });
                navigator.sendBeacon('/api/secure-video/session/end', new Blob([data], { type: 'application/json' }));
            }
        });
    }

    function _startHeartbeat() {
        if (_heartbeatInterval) clearInterval(_heartbeatInterval);
        _heartbeatInterval = setInterval(function () {
            if (!_sessionToken) return;
            _apiPost('/api/secure-video/session/heartbeat', {
                sessionToken: _sessionToken,
                position: Math.floor(_currentTime),
                isPaused: !_isPlaying
            }).catch(function () {});
        }, 30000);
    }

    // ============================================================
    // PROGRESS TRACKING
    // ============================================================
    function _autoTrack() {
        if (!_config.lessonId || _currentTime < 0) return;
        var sec = Math.floor(_currentTime);
        if (sec - _lastTrackedSec >= 5) {
            _lastTrackedSec = sec;
            _trackProgress(sec, false);
        }
    }

    function _trackProgress(sec, completed) {
        var token = document.querySelector('input[name="__RequestVerificationToken"]');
        fetch(_config.progressUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': token ? token.value : ''
            },
            credentials: 'same-origin',
            body: JSON.stringify({ lessonId: _config.lessonId, watchedSeconds: sec, completed: completed || false })
        }).catch(function () {});
    }

    // ============================================================
    // UI HELPERS
    // ============================================================
    function _updateProgressUI() {
        if (!_duration) return;
        var pct = (_currentTime / _duration * 100);
        _els.progressFill.style.width = pct + '%';
        _els.timeDisplay.textContent = _formatTime(_currentTime) + ' / ' + _formatTime(_duration);
    }

    function _formatTime(s) {
        if (!s || isNaN(s)) return '0:00';
        s = Math.floor(s);
        var h = Math.floor(s / 3600);
        var m = Math.floor((s % 3600) / 60);
        var sec = s % 60;
        if (h > 0) return h + ':' + (m < 10 ? '0' : '') + m + ':' + (sec < 10 ? '0' : '') + sec;
        return m + ':' + (sec < 10 ? '0' : '') + sec;
    }

    function _setPlayingIcon() {
        _els.playIcon.innerHTML = '<rect x="6" y="4" width="4" height="16" fill="currentColor"/><rect x="14" y="4" width="4" height="16" fill="currentColor"/>';
    }
    function _setPausedIcon() {
        _els.playIcon.innerHTML = '<polygon points="5,3 19,12 5,21" fill="currentColor"/>';
    }
    function _updateVolIcon() {
        _els.volumeIcon.innerHTML = _isMuted
            ? '<path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/>'
            : '<path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/>';
    }
    function _updateFsIcon() {
        var isFs = !!(document.fullscreenElement || document.webkitFullscreenElement);
        _els.fsIcon.innerHTML = isFs
            ? '<path d="M5 16h3v3h2v-5H5v2zm3-8H5v2h5V5H8v3zm6 11h2v-3h3v-2h-5v5zm2-11V5h-2v5h5V8h-3z"/>'
            : '<path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/>';
    }

    function _showOverlay(text, sub) {
        _els.overlayText.textContent = text;
        _els.overlaySubtext.textContent = sub || '';
        _els.overlay.classList.add('show');
    }
    function _hideOverlay() { _els.overlay.classList.remove('show'); }
    function _showLoader() { if (_els.loader) _els.loader.classList.add('show'); }
    function _hideLoader() { if (_els.loader) _els.loader.classList.remove('show'); }
    function _showError(msg) {
        _clearLoadTimeout();
        _hideLoader();
        if (_els.error) { _els.error.classList.remove('hidden'); if (_els.errorMsg) _els.errorMsg.textContent = msg; }
    }
    function _hideError() { if (_els.error) _els.error.classList.add('hidden'); }
    function _showRecordingWarning() { if (_els.recordingWarning) _els.recordingWarning.classList.remove('hidden'); }
    function _hideRecordingWarning() { if (_els.recordingWarning) _els.recordingWarning.classList.add('hidden'); }

    function _pauseVideo() {
        if (_config.provider === 'youtube' && _player) _player.pauseVideo();
        else if (_config.provider === 'vimeo' && _player) _player.pause();
        else if (_videoEl) _videoEl.pause();
    }

    // Controls visibility
    function _showControlsThenHide() {
        _showControls();
        if (_controlsTimeout) clearTimeout(_controlsTimeout);
        if (_isPlaying) {
            _controlsTimeout = setTimeout(_hideControls, 3000);
        }
    }
    function _showControlsPermanent() {
        _showControls();
        if (_controlsTimeout) clearTimeout(_controlsTimeout);
    }
    function _showControls() {
        _controlsVisible = true;
        if (_els.controls) _els.controls.classList.add('visible');
        _container.classList.remove('svp-cursor-hidden');
    }
    function _hideControls() {
        _controlsVisible = false;
        if (_els.controls) _els.controls.classList.remove('visible');
        _container.classList.add('svp-cursor-hidden');
        _closeDropdowns();
    }

    // Dropdowns
    function _toggleDropdown(menu) {
        if (_dropdownOpen === menu) {
            _closeDropdowns();
        } else {
            _closeDropdowns();
            menu.classList.add('open');
            _dropdownOpen = menu;
        }
    }
    function _closeDropdowns() {
        if (_dropdownOpen) { _dropdownOpen.classList.remove('open'); _dropdownOpen = null; }
    }

    // ============================================================
    // DEVICE FINGERPRINT
    // ============================================================
    function _generateFingerprint() {
        var parts = [
            screen.width + 'x' + screen.height + 'x' + screen.colorDepth,
            navigator.language,
            navigator.platform,
            navigator.hardwareConcurrency || 0,
            Intl.DateTimeFormat().resolvedOptions().timeZone,
            window.devicePixelRatio || 1
        ];
        _deviceFingerprint = _simpleHash(parts.join('|'));
    }

    function _simpleHash(str) {
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
            hash = ((hash << 5) - hash) + str.charCodeAt(i);
            hash |= 0;
        }
        return Math.abs(hash).toString(36);
    }

    function _getDeviceInfo() {
        var ua = navigator.userAgent;
        var os = /Windows/.test(ua) ? 'Windows' : /Mac/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : /Android/.test(ua) ? 'Android' : /iPhone|iPad/.test(ua) ? 'iOS' : 'Unknown';
        var browser = /Chrome/.test(ua) && !/Edge|OPR/.test(ua) ? 'Chrome' : /Firefox/.test(ua) ? 'Firefox' : /Safari/.test(ua) && !/Chrome/.test(ua) ? 'Safari' : /Edge/.test(ua) ? 'Edge' : 'Unknown';
        var deviceType = /Mobile|Android|iPhone/.test(ua) ? 'Mobile' : /Tablet|iPad/.test(ua) ? 'Tablet' : 'Desktop';
        return { os: os, browser: browser, deviceType: deviceType };
    }

    // ============================================================
    // API HELPERS
    // ============================================================
    function _apiPost(url, data) {
        return fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Device-Fingerprint': _deviceFingerprint
            },
            credentials: 'same-origin',
            body: JSON.stringify(data)
        }).then(function (r) { return r.json(); }).catch(function () { return {}; });
    }

    function _reportSuspicious(type, desc, risk) {
        if (!_config.lessonId) return;
        _apiPost('/api/secure-video/report/suspicious', {
            lessonId: _config.lessonId,
            activityType: type,
            description: desc,
            riskScore: risk || 10
        }).catch(function () {});
    }

    // ============================================================
    // CLEANUP
    // ============================================================
    function destroy() {
        if (_progressInterval) clearInterval(_progressInterval);
        if (_heartbeatInterval) clearInterval(_heartbeatInterval);
        if (_watermarkInterval) clearInterval(_watermarkInterval);
        if (_watermarkAnimFrame) cancelAnimationFrame(_watermarkAnimFrame);
        if (_controlsTimeout) clearTimeout(_controlsTimeout);
        if (_sessionToken) {
            var data = JSON.stringify({ sessionToken: _sessionToken, reason: 'Destroyed' });
            navigator.sendBeacon('/api/secure-video/session/end', new Blob([data], { type: 'application/json' }));
        }
    }

    // ============================================================
    // PUBLIC API
    // ============================================================
    return {
        init: init,
        destroy: destroy,
        play: function () { _toggle(); },
        pause: function () { _pauseVideo(); },
        getCurrentTime: function () { return _currentTime; },
        getDuration: function () { return _duration; },
        seekTo: function (seconds) { _seekTo(seconds); }
    };
})();
