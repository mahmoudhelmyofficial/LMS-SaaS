/**
 * WEBUILDER LMS - Content Protection Module
 * Comprehensive protection against content theft
 * @version 2.0.0
 * @author WEBUILDER Platform
 */
(function () {
    'use strict';

    const ContentProtection = {
        config: {
            enabled: true,
            showWarning: true,
            warningMessage: 'هذا المحتوى محمي بحقوق الملكية الفكرية',
            warningDuration: 2500,
            preventRightClick: true,
            preventKeyboardShortcuts: true,
            preventTextSelection: true,
            preventDragDrop: true,
            preventPrint: true,
            detectDevTools: true,
            debugMode: false
        },

        warningElement: null,
        devToolsOpen: false,

        /**
         * Initialize all protection mechanisms
         */
        init: function (customConfig = {}) {
            // Merge custom config
            this.config = { ...this.config, ...customConfig };

            if (!this.config.enabled) {
                this.log('Content protection is disabled');
                return;
            }

            this.log('Initializing content protection...');

            // Apply protections
            if (this.config.preventRightClick) this.preventRightClick();
            if (this.config.preventKeyboardShortcuts) this.preventKeyboardShortcuts();
            if (this.config.preventTextSelection) this.preventTextSelection();
            if (this.config.preventDragDrop) this.preventDragAndDrop();
            if (this.config.preventPrint) this.preventPrint();
            if (this.config.detectDevTools) this.detectDevTools();

            // Prevent copy events
            this.preventCopy();

            // Create warning element
            this.createWarningElement();

            this.log('Content protection initialized successfully');
        },

        /**
         * Logging helper
         */
        log: function (message) {
            if (this.config.debugMode) {
                console.log('[ContentProtection]', message);
            }
        },

        /**
         * Prevent right-click context menu
         */
        preventRightClick: function () {
            document.addEventListener('contextmenu', (e) => {
                // Allow right-click on input fields for accessibility
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return true;
                }
                e.preventDefault();
                this.showProtectedWarning();
                return false;
            }, false);

            this.log('Right-click prevention enabled');
        },

        /**
         * Prevent keyboard shortcuts for saving, printing, viewing source
         */
        preventKeyboardShortcuts: function () {
            document.addEventListener('keydown', (e) => {
                const key = e.key.toLowerCase();

                // F12 - Developer Tools
                if (e.key === 'F12') {
                    e.preventDefault();
                    this.showProtectedWarning();
                    return false;
                }

                // Ctrl + combinations
                if (e.ctrlKey) {
                    // Ctrl + S (Save)
                    // Ctrl + U (View Source)
                    // Ctrl + P (Print)
                    // Ctrl + A (Select All) - in protected areas
                    if (['s', 'u', 'p'].includes(key)) {
                        e.preventDefault();
                        this.showProtectedWarning();
                        return false;
                    }

                    // Ctrl + Shift + combinations
                    if (e.shiftKey) {
                        // Ctrl + Shift + I (Developer Tools)
                        // Ctrl + Shift + J (Console)
                        // Ctrl + Shift + C (Inspect Element)
                        if (['i', 'j', 'c'].includes(key)) {
                            e.preventDefault();
                            this.showProtectedWarning();
                            return false;
                        }
                    }
                }

                // Prevent PrintScreen
                if (e.key === 'PrintScreen') {
                    e.preventDefault();
                    // Clear clipboard
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText('محتوى محمي - لا يمكن نسخه');
                    }
                    this.showProtectedWarning();
                    return false;
                }
            }, false);

            // Additional keyup handler for PrintScreen
            document.addEventListener('keyup', (e) => {
                if (e.key === 'PrintScreen') {
                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText('محتوى محمي - لا يمكن نسخه');
                    }
                }
            }, false);

            this.log('Keyboard shortcuts prevention enabled');
        },

        /**
         * Prevent text selection
         */
        preventTextSelection: function () {
            // Apply to body
            document.body.classList.add('no-select');

            // CSS handles most of it, but also add event listeners
            document.addEventListener('selectstart', (e) => {
                // Allow selection in input fields
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return true;
                }
                e.preventDefault();
                return false;
            }, false);

            this.log('Text selection prevention enabled');
        },

        /**
         * Prevent drag and drop of content
         */
        preventDragAndDrop: function () {
            document.addEventListener('dragstart', (e) => {
                e.preventDefault();
                return false;
            }, false);

            document.addEventListener('drop', (e) => {
                e.preventDefault();
                return false;
            }, false);

            // Prevent dragging images
            document.querySelectorAll('img, video').forEach(el => {
                el.setAttribute('draggable', 'false');
            });

            this.log('Drag and drop prevention enabled');
        },

        /**
         * Prevent copy events
         */
        preventCopy: function () {
            document.addEventListener('copy', (e) => {
                // Allow copy in input fields
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return true;
                }
                e.preventDefault();
                // Set clipboard to warning message
                if (e.clipboardData) {
                    e.clipboardData.setData('text/plain', 'محتوى محمي - لا يمكن نسخه');
                }
                this.showProtectedWarning();
                return false;
            }, false);

            document.addEventListener('cut', (e) => {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
                    return true;
                }
                e.preventDefault();
                this.showProtectedWarning();
                return false;
            }, false);

            this.log('Copy prevention enabled');
        },

        /**
         * Prevent printing
         */
        preventPrint: function () {
            // Handle before print event
            window.addEventListener('beforeprint', (e) => {
                document.body.classList.add('print-blocked');
            });

            window.addEventListener('afterprint', () => {
                document.body.classList.remove('print-blocked');
            });

            // Override window.print
            const originalPrint = window.print;
            window.print = () => {
                this.showProtectedWarning();
                return false;
            };

            this.log('Print prevention enabled');
        },

        /**
         * Detect Developer Tools
         */
        detectDevTools: function () {
            const threshold = 160;

            const checkDevTools = () => {
                const widthThreshold = window.outerWidth - window.innerWidth > threshold;
                const heightThreshold = window.outerHeight - window.innerHeight > threshold;

                if (widthThreshold || heightThreshold) {
                    if (!this.devToolsOpen) {
                        this.devToolsOpen = true;
                        this.onDevToolsOpen();
                    }
                } else {
                    if (this.devToolsOpen) {
                        this.devToolsOpen = false;
                        this.onDevToolsClose();
                    }
                }
            };

            // Check periodically
            setInterval(checkDevTools, 1000);

            // Also check on resize
            window.addEventListener('resize', checkDevTools);

            this.log('DevTools detection enabled');
        },

        /**
         * Handler when DevTools opens
         */
        onDevToolsOpen: function () {
            this.log('DevTools detected as open');
            // Optional: You can add more aggressive measures here
            // Like pausing videos or showing a permanent overlay
        },

        /**
         * Handler when DevTools closes
         */
        onDevToolsClose: function () {
            this.log('DevTools detected as closed');
        },

        /**
         * Create the warning element (only once)
         */
        createWarningElement: function () {
            if (this.warningElement) return;

            this.warningElement = document.createElement('div');
            this.warningElement.id = 'content-protection-warning';
            this.warningElement.className = 'protection-warning-overlay';
            this.warningElement.innerHTML = `
                <div class="protection-warning-content">
                    <div class="protection-warning-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                            <path d="M12 8v4"></path>
                            <path d="M12 16h.01"></path>
                        </svg>
                    </div>
                    <h3 class="protection-warning-title">🔒 محتوى محمي</h3>
                    <p class="protection-warning-message">${this.config.warningMessage}</p>
                </div>
            `;
            document.body.appendChild(this.warningElement);
        },

        /**
         * Show the protected content warning
         */
        showProtectedWarning: function () {
            if (!this.config.showWarning || !this.warningElement) return;

            // Show warning
            this.warningElement.classList.add('show');

            // Hide after duration
            setTimeout(() => {
                this.warningElement.classList.remove('show');
            }, this.config.warningDuration);
        },

        /**
         * Enable protection (can be called after init)
         */
        enable: function () {
            this.config.enabled = true;
            document.body.classList.add('content-protected');
        },

        /**
         * Disable protection (for admin/instructor areas)
         */
        disable: function () {
            this.config.enabled = false;
            document.body.classList.remove('content-protected', 'no-select');
        }
    };

    // Auto-initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => ContentProtection.init());
    } else {
        ContentProtection.init();
    }

    // Expose globally for configuration
    window.ContentProtection = ContentProtection;

})();

