/**
 * Course Creation Wizard - Enterprise-level UX
 * معالج إنشاء الدورة
 */
class CourseWizard {
    constructor(options = {}) {
        this.courseId = options.courseId || 0;
        this.currentStep = options.currentStep || 1;
        this.antiForgeryToken = options.antiForgeryToken;
        this.autoSaveDelay = options.autoSaveDelay || 2000;
        this.autoSaveTimer = null;
        this.isDirty = false;
        this.lastSavedData = {};
        
        this.init();
    }

    init() {
        this.setupAutoSave();
        this.setupFormValidation();
        this.setupKeyboardShortcuts();
        this.setupBeforeUnload();
        this.setupProgressTracking();
    }

    /**
     * Auto-save functionality
     */
    setupAutoSave() {
        const autoSaveFields = document.querySelectorAll('[data-autosave="true"]');
        
        autoSaveFields.forEach(field => {
            field.addEventListener('input', () => this.scheduleAutoSave(field));
            field.addEventListener('change', () => this.scheduleAutoSave(field));
        });
    }

    scheduleAutoSave(field) {
        this.isDirty = true;
        this.updateAutoSaveIndicator('typing');

        clearTimeout(this.autoSaveTimer);
        this.autoSaveTimer = setTimeout(() => {
            this.performAutoSave(field);
        }, this.autoSaveDelay);
    }

    async performAutoSave(field) {
        if (!this.courseId) {
            // For new courses, just show that changes are pending
            this.updateAutoSaveIndicator('pending');
            return;
        }

        const fieldName = field.name || field.id;
        const fieldValue = field.type === 'checkbox' ? field.checked.toString() : field.value;

        // Skip if value hasn't changed
        if (this.lastSavedData[fieldName] === fieldValue) {
            return;
        }

        this.updateAutoSaveIndicator('saving');

        try {
            const response = await fetch('/Instructor/Courses/AutoSave', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': this.antiForgeryToken
                },
                body: JSON.stringify({
                    courseId: this.courseId,
                    field: fieldName,
                    value: fieldValue,
                    step: this.currentStep
                })
            });

            const result = await response.json();

            if (result.success) {
                this.lastSavedData[fieldName] = fieldValue;
                this.isDirty = false;
                
                // Update courseId if new course was created
                if (result.courseId && !this.courseId) {
                    this.courseId = result.courseId;
                    // Update hidden field if exists
                    const idField = document.querySelector('[name="Id"]');
                    if (idField) idField.value = this.courseId;
                }
                
                this.updateAutoSaveIndicator('saved');
            } else {
                this.updateAutoSaveIndicator('error');
            }
        } catch (error) {
            console.error('Auto-save error:', error);
            this.updateAutoSaveIndicator('error');
        }
    }

    updateAutoSaveIndicator(status) {
        const indicator = document.getElementById('autoSaveIndicator');
        const text = document.getElementById('autoSaveText');
        
        if (!indicator || !text) return;

        indicator.classList.remove('saving', 'saved', 'error');
        
        switch (status) {
            case 'typing':
                text.textContent = 'جاري الكتابة...';
                break;
            case 'pending':
                text.textContent = 'تغييرات غير محفوظة';
                indicator.classList.add('error');
                break;
            case 'saving':
                text.textContent = 'جاري الحفظ...';
                indicator.classList.add('saving');
                break;
            case 'saved':
                text.textContent = 'تم الحفظ';
                indicator.classList.add('saved');
                // Reset after 3 seconds
                setTimeout(() => {
                    text.textContent = 'الحفظ التلقائي مفعّل';
                    indicator.classList.remove('saved');
                }, 3000);
                break;
            case 'error':
                text.textContent = 'فشل الحفظ';
                indicator.classList.add('error');
                break;
        }
    }

    /**
     * Form validation
     */
    setupFormValidation() {
        const form = document.getElementById('wizardForm');
        if (!form) return;

        form.addEventListener('submit', (e) => {
            if (!this.validateCurrentStep()) {
                e.preventDefault();
                this.showValidationErrors();
            }
        });
    }

    validateCurrentStep() {
        const validations = {
            1: this.validateStep1.bind(this),
            2: this.validateStep2.bind(this),
            3: this.validateStep3.bind(this),
            4: this.validateStep4.bind(this),
            5: this.validateStep5.bind(this),
            6: () => true, // Settings are optional
            7: this.validateStep7.bind(this)
        };

        const validator = validations[this.currentStep];
        return validator ? validator() : true;
    }

    validateStep1() {
        const errors = [];
        const title = document.getElementById('Title');
        const shortDesc = document.getElementById('ShortDescription');
        const description = document.getElementById('Description');
        // Support both ID formats: 'CategoryId' (standard form) and 'categorySelect' (wizard)
        const categoryId = document.getElementById('CategoryId') || document.getElementById('categorySelect');

        if (!title?.value || title.value.length < 10) {
            errors.push('عنوان الدورة يجب أن يكون 10 أحرف على الأقل');
            title?.classList.add('is-invalid');
        }

        if (!shortDesc?.value || shortDesc.value.length < 20) {
            errors.push('الوصف المختصر يجب أن يكون 20 حرف على الأقل');
            shortDesc?.classList.add('is-invalid');
        }

        if (!description?.value || description.value.length < 100) {
            errors.push('الوصف التفصيلي يجب أن يكون 100 حرف على الأقل');
            description?.classList.add('is-invalid');
        }

        if (!categoryId?.value || categoryId.value === '0' || categoryId.value === '') {
            errors.push('يجب اختيار التصنيف');
            categoryId?.classList.add('is-invalid');
        }

        this.validationErrors = errors;
        return errors.length === 0;
    }

    validateStep2() {
        const errors = [];
        const outcomes = document.querySelectorAll('[name^="LearningOutcomes"]');
        const requirements = document.querySelectorAll('[name^="Requirements"]');

        const filledOutcomes = Array.from(outcomes).filter(o => o.value.trim());
        if (filledOutcomes.length < 3) {
            errors.push('يجب إضافة 3 نقاط تعلم على الأقل');
        }

        const filledRequirements = Array.from(requirements).filter(r => r.value.trim());
        if (filledRequirements.length < 1) {
            errors.push('يجب إضافة متطلب واحد على الأقل');
        }

        this.validationErrors = errors;
        return errors.length === 0;
    }

    validateStep3() {
        // Content is validated on the server
        return true;
    }

    validateStep4() {
        const errors = [];
        const thumbnail = document.getElementById('ThumbnailUrl');
        const thumbnailFile = document.getElementById('ThumbnailFile');

        // Check if either URL or file is provided
        const hasImage = (thumbnail?.value) || (thumbnailFile?.files?.length > 0);
        
        // For step 4, thumbnail is required but we allow navigation
        // The readiness check will show it's missing
        this.validationErrors = errors;
        return true;
    }

    validateStep5() {
        const errors = [];
        const isFree = document.getElementById('isFreeInput')?.value === 'true';
        const price = parseFloat(document.getElementById('priceInput')?.value) || 0;
        const discountPrice = parseFloat(document.getElementById('discountPriceInput')?.value) || 0;

        if (!isFree && price <= 0) {
            errors.push('يجب تحديد سعر للدورة أو جعلها مجانية');
        }

        if (discountPrice > 0 && discountPrice >= price) {
            errors.push('سعر الخصم يجب أن يكون أقل من السعر الأصلي');
        }

        this.validationErrors = errors;
        return errors.length === 0;
    }

    validateStep7() {
        // Final validation - aggregate all checks
        return true;
    }

    showValidationErrors() {
        if (!this.validationErrors || this.validationErrors.length === 0) return;

        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'validation-toast';
        toast.innerHTML = `
            <div class="toast-header">
                <i class="feather-alert-circle text-danger me-2"></i>
                <strong>يرجى تصحيح الأخطاء التالية:</strong>
            </div>
            <div class="toast-body">
                <ul class="mb-0">
                    ${this.validationErrors.map(e => `<li>${e}</li>`).join('')}
                </ul>
            </div>
        `;

        document.body.appendChild(toast);

        // Add styles
        toast.style.cssText = `
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background: white;
            border-radius: 8px;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            padding: 15px 20px;
            z-index: 9999;
            animation: slideDown 0.3s ease;
            max-width: 400px;
        `;

        // Remove after 5 seconds
        setTimeout(() => {
            toast.style.animation = 'slideUp 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    /**
     * Keyboard shortcuts
     */
    setupKeyboardShortcuts() {
        document.addEventListener('keydown', (e) => {
            // Ctrl/Cmd + S = Save draft
            if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                e.preventDefault();
                const draftBtn = document.querySelector('[name="action"][value="draft"]');
                if (draftBtn) draftBtn.click();
            }

            // Ctrl/Cmd + Enter = Next step
            if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
                e.preventDefault();
                const nextBtn = document.querySelector('[name="action"][value="next"]');
                if (nextBtn && !nextBtn.disabled) nextBtn.click();
            }
        });
    }

    /**
     * Before unload warning
     */
    setupBeforeUnload() {
        window.addEventListener('beforeunload', (e) => {
            if (this.isDirty) {
                e.preventDefault();
                e.returnValue = 'لديك تغييرات غير محفوظة. هل تريد المغادرة؟';
                return e.returnValue;
            }
        });

        // Mark form as clean when submitting
        const form = document.getElementById('wizardForm');
        if (form) {
            form.addEventListener('submit', () => {
                this.isDirty = false;
            });
        }
    }

    /**
     * Progress tracking
     */
    setupProgressTracking() {
        this.updateProgressUI();

        // Listen for changes to update progress
        document.addEventListener('input', () => {
            clearTimeout(this.progressTimer);
            this.progressTimer = setTimeout(() => {
                this.updateProgressUI();
            }, 500);
        });
    }

    updateProgressUI() {
        // Calculate completion based on current form state
        const items = [
            this.checkField('Title', 10),
            this.checkField('ShortDescription', 20),
            this.checkField('Description', 100),
            this.checkSelect('CategoryId'),
            this.checkListItems('[name^="LearningOutcomes"]', 3),
            this.checkListItems('[name^="Requirements"]', 1),
            // Content check done via data attributes
            this.checkField('ThumbnailUrl', 1) || document.getElementById('ThumbnailFile')?.files?.length > 0,
            this.checkPricing()
        ];

        const completed = items.filter(Boolean).length;
        const total = items.length;
        const percentage = Math.round((completed / total) * 100);

        // Update score circle if exists
        const scoreCircle = document.querySelector('.score-circle');
        if (scoreCircle) {
            scoreCircle.style.setProperty('--progress', `${percentage * 3.6}deg`);
            const scoreValue = scoreCircle.querySelector('.score-value');
            if (scoreValue) scoreValue.textContent = percentage + '%';
        }
    }

    checkField(id, minLength) {
        const field = document.getElementById(id);
        return field && field.value && field.value.length >= minLength;
    }

    checkSelect(id) {
        // Support fallback ID for category select (CategoryId -> categorySelect)
        let field = document.getElementById(id);
        if (!field && id === 'CategoryId') {
            field = document.getElementById('categorySelect');
        }
        return field && field.value && field.value !== '0' && field.value !== '';
    }

    checkListItems(selector, minCount) {
        const items = document.querySelectorAll(selector);
        const filledItems = Array.from(items).filter(i => i.value.trim());
        return filledItems.length >= minCount;
    }

    checkPricing() {
        const isFree = document.getElementById('isFreeInput')?.value === 'true';
        const price = parseFloat(document.getElementById('priceInput')?.value) || 0;
        return isFree || price > 0;
    }
}

// Utility functions
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.innerHTML = `
        <i class="feather-${type === 'success' ? 'check-circle' : type === 'error' ? 'x-circle' : 'info'}"></i>
        <span>${message}</span>
    `;
    
    document.body.appendChild(toast);
    
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        left: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#667eea'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 8px;
        box-shadow: 0 4px 20px rgba(0,0,0,0.2);
        z-index: 9999;
        animation: slideInLeft 0.3s ease;
    `;
    
    setTimeout(() => {
        toast.style.animation = 'slideOutLeft 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideDown {
        from { opacity: 0; transform: translate(-50%, -20px); }
        to { opacity: 1; transform: translate(-50%, 0); }
    }
    @keyframes slideUp {
        from { opacity: 1; transform: translate(-50%, 0); }
        to { opacity: 0; transform: translate(-50%, -20px); }
    }
    @keyframes slideInLeft {
        from { opacity: 0; transform: translateX(-100px); }
        to { opacity: 1; transform: translateX(0); }
    }
    @keyframes slideOutLeft {
        from { opacity: 1; transform: translateX(0); }
        to { opacity: 0; transform: translateX(-100px); }
    }
    
    .validation-toast .toast-header {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
        font-size: 14px;
    }
    
    .validation-toast .toast-body ul {
        list-style: none;
        padding: 0;
        margin: 0;
    }
    
    .validation-toast .toast-body li {
        padding: 4px 0;
        font-size: 13px;
        color: #666;
    }
    
    .validation-toast .toast-body li::before {
        content: '•';
        color: #ef4444;
        margin-right: 8px;
    }
`;
document.head.appendChild(style);

// Export for use
window.CourseWizard = CourseWizard;
window.showToast = showToast;

