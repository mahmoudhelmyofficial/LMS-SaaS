// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

/**
 * GLOBAL MODAL FIX
 * 1. Removes orphaned/duplicate .modal-backdrop elements (fixes extra overlay blocking modals).
 * 2. Ensures the single backdrop is placed before the modal in the DOM so it never covers the modal (Bootstrap appends to body, so without this the backdrop appears on top).
 * 3. Fixes stacking context issues with backdrop-filter on glass elements.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        initModalFix();
    });

    /** Remove all .modal-backdrop elements only (e.g. before opening a modal to avoid duplicates). */
    function removeBackdropElements() {
        document.querySelectorAll('.modal-backdrop').forEach(function(el) { el.remove(); });
    }

    /** Remove backdrops and restore body state. Call when no modal is visible (after close). */
    function removeOrphanedBackdrops() {
        removeBackdropElements();
        document.body.classList.remove('modal-open');
        document.body.style.removeProperty('overflow');
        document.body.style.removeProperty('padding-right');
    }

    /** Return true if any Bootstrap modal is currently shown. */
    function hasVisibleModal() {
        return document.querySelectorAll('.modal.show').length > 0;
    }

    /**
     * Ensure only one backdrop exists and it is placed BEFORE the visible modal(s) in the DOM.
     * Bootstrap appends the backdrop to body, so when modals are at end of body the backdrop
     * ends up on top and blocks interaction. Moving backdrop before the modal fixes stacking.
     */
    function ensureBackdropBelowModal() {
        var backdrops = document.querySelectorAll('.modal-backdrop');
        var visibleModals = document.querySelectorAll('.modal.show');
        if (backdrops.length === 0 || visibleModals.length === 0) { return; }
        // Remove duplicate backdrops (keep only the first)
        for (var i = 1; i < backdrops.length; i++) {
            backdrops[i].remove();
        }
        var backdrop = document.querySelector('.modal-backdrop');
        var firstVisibleModal = document.querySelector('.modal.show');
        if (backdrop && firstVisibleModal && backdrop.nextElementSibling !== firstVisibleModal) {
            document.body.insertBefore(backdrop, firstVisibleModal);
        }
    }

    function initModalFix() {
        // Move all modals to end of body to avoid stacking context issues
        var modals = document.querySelectorAll('.modal');
        modals.forEach(function(modal) {
            if (modal.parentElement !== document.body) {
                document.body.appendChild(modal);
            }
        });

        document.addEventListener('show.bs.modal', handleModalShow);
        document.addEventListener('shown.bs.modal', handleModalShown);
        document.addEventListener('hidden.bs.modal', handleModalHidden);

        var observer = new MutationObserver(function(mutations) {
            var backdropAdded = false;
            mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                    if (node.nodeType === 1 && node.classList) {
                        if (node.classList.contains('modal')) {
                            if (node.parentElement !== document.body) {
                                document.body.appendChild(node);
                            }
                        } else if (node.classList.contains('modal-backdrop')) {
                            backdropAdded = true;
                        }
                    }
                });
            });
            if (backdropAdded) {
                ensureBackdropBelowModal();
            }
        });

        observer.observe(document.body, { childList: true, subtree: true });
    }

    function handleModalShow(event) {
        // Remove any orphaned backdrop elements so only one will be created for this modal
        removeBackdropElements();

        // Schedule ensuring backdrop stays below modal (Bootstrap may add it during show)
        setTimeout(ensureBackdropBelowModal, 0);

        // Disable backdrop-filter on glass elements when modal opens
        var glassElements = document.querySelectorAll('.glass-banner, .glass-card, [class*="glass"]');
        glassElements.forEach(function(el) {
            el.dataset.originalBackdropFilter = el.style.backdropFilter || '';
            el.dataset.originalWebkitBackdropFilter = el.style.webkitBackdropFilter || '';
            el.style.setProperty('backdrop-filter', 'none', 'important');
            el.style.setProperty('-webkit-backdrop-filter', 'none', 'important');
        });

        // Ensure modal content is visible
        var modal = event.target;
        var modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            modalContent.style.setProperty('opacity', '1', 'important');
            modalContent.style.setProperty('background-color', '#ffffff', 'important');
            modalContent.style.setProperty('filter', 'none', 'important');
        }
    }

    function handleModalShown(event) {
        // Ensure only one backdrop exists and it is below the modal in DOM (fixes overlay blocking modal)
        ensureBackdropBelowModal();
        requestAnimationFrame(ensureBackdropBelowModal);

        // Additional enforcement after modal is fully shown
        var modal = event.target;
        var modalContent = modal.querySelector('.modal-content');
        if (modalContent) {
            modalContent.style.setProperty('opacity', '1', 'important');
            modalContent.style.setProperty('background-color', '#ffffff', 'important');
            modalContent.style.setProperty('filter', 'none', 'important');
            modalContent.style.setProperty('z-index', '1065', 'important');
        }

        // Ensure modal dialog is properly positioned
        var modalDialog = modal.querySelector('.modal-dialog');
        if (modalDialog) {
            modalDialog.style.setProperty('z-index', '1060', 'important');
        }
    }

    function handleModalHidden(event) {
        // Clean up all backdrops and body state when no modal is visible (fixes duplicate overlay)
        if (!hasVisibleModal()) {
            removeOrphanedBackdrops();
            // Delayed cleanup in case Bootstrap removes backdrop asynchronously and one is left behind
            setTimeout(function() {
                if (!hasVisibleModal()) {
                    removeOrphanedBackdrops();
                }
            }, 100);
        }

        // Restore backdrop-filter on glass elements when modal closes
        var glassElements = document.querySelectorAll('.glass-banner, .glass-card, [class*="glass"]');
        glassElements.forEach(function(el) {
            if (el.dataset.originalBackdropFilter !== undefined) {
                if (el.dataset.originalBackdropFilter) {
                    el.style.backdropFilter = el.dataset.originalBackdropFilter;
                } else {
                    el.style.removeProperty('backdrop-filter');
                }
                delete el.dataset.originalBackdropFilter;
            }
            if (el.dataset.originalWebkitBackdropFilter !== undefined) {
                if (el.dataset.originalWebkitBackdropFilter) {
                    el.style.webkitBackdropFilter = el.dataset.originalWebkitBackdropFilter;
                } else {
                    el.style.removeProperty('-webkit-backdrop-filter');
                }
                delete el.dataset.originalWebkitBackdropFilter;
            }
        });
    }
})();