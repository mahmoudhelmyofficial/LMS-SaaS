/**
 * Instructor Category Manager
 * Handles on-the-fly category and subcategory creation for the Instructor Dashboard
 * 
 * Usage:
 * 1. Include this script in your view
 * 2. Include the _CategoryModals.cshtml partial
 * 3. Call InstructorCategoryManager.init({ categorySelectId: 'yourCategorySelectId', ... })
 */

const InstructorCategoryManager = {
    // Configuration
    config: {
        categorySelectId: 'categorySelect',
        subcategorySelectId: 'subcategorySelect',
        addSubcategoryBtnId: 'addSubcategoryBtn',
        apiBaseUrl: '/Instructor/Courses',
        onCategoryAdded: null,
        onSubcategoryAdded: null,
        onError: null
    },

    /**
     * Initialize the category manager
     * @param {Object} options - Configuration options
     */
    init: function(options) {
        // Merge options with defaults
        this.config = { ...this.config, ...options };
        
        // Bind events
        this.bindEvents();
        
        // Initial state
        this.updateSubcategoryButtonState();
        
        console.log('InstructorCategoryManager initialized');
    },

    /**
     * Bind all event listeners
     */
    bindEvents: function() {
        const self = this;
        const categorySelect = document.getElementById(this.config.categorySelectId);
        const iconInput = document.getElementById('newCategoryIcon');
        
        // Category select change event
        if (categorySelect) {
            categorySelect.addEventListener('change', function() {
                self.onCategoryChange(this);
            });
        }
        
        // Icon preview update
        if (iconInput) {
            iconInput.addEventListener('input', function() {
                const preview = document.getElementById('categoryIconPreview');
                if (preview) {
                    preview.className = 'feather-' + (this.value || 'book');
                }
            });
        }
        
        // Modal events - reset forms when closed
        const categoryModal = document.getElementById('addCategoryModal');
        const subcategoryModal = document.getElementById('addSubcategoryModal');
        
        if (categoryModal) {
            categoryModal.addEventListener('hidden.bs.modal', function() {
                self.resetCategoryForm();
            });
        }
        
        if (subcategoryModal) {
            subcategoryModal.addEventListener('hidden.bs.modal', function() {
                self.resetSubcategoryForm();
            });
        }
        
        // Enter key submission
        document.getElementById('newCategoryName')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                self.saveCategory();
            }
        });
        
        document.getElementById('newSubcategoryName')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                self.saveSubcategory();
            }
        });
    },

    /**
     * Handle category selection change
     * @param {HTMLElement} selectElement - The category select element
     */
    onCategoryChange: async function(selectElement) {
        const categoryId = selectElement.value;
        const selectedOption = selectElement.options[selectElement.selectedIndex];
        
        // Update parent category info for subcategory modal
        const parentCategoryId = document.getElementById('parentCategoryId');
        const parentCategoryName = document.getElementById('parentCategoryName');
        
        if (parentCategoryId) parentCategoryId.value = categoryId;
        if (parentCategoryName) parentCategoryName.value = selectedOption?.text || '';
        
        // Update subcategory button state
        this.updateSubcategoryButtonState();
        
        // Load subcategories
        await this.loadSubcategories(categoryId);
    },

    /**
     * Update the state of the add subcategory button
     */
    updateSubcategoryButtonState: function() {
        const categorySelect = document.getElementById(this.config.categorySelectId);
        const addSubcategoryBtn = document.getElementById(this.config.addSubcategoryBtnId);
        
        if (addSubcategoryBtn) {
            const hasCategory = categorySelect && categorySelect.value;
            addSubcategoryBtn.disabled = !hasCategory;
            
            if (!hasCategory) {
                addSubcategoryBtn.title = 'اختر التصنيف الرئيسي أولاً';
            } else {
                addSubcategoryBtn.title = 'إضافة تصنيف فرعي';
            }
        }
    },

    /**
     * Load subcategories for a given category
     * @param {number|string} categoryId - The parent category ID
     */
    loadSubcategories: async function(categoryId) {
        const subcategorySelect = document.getElementById(this.config.subcategorySelectId);
        
        if (!subcategorySelect) return;
        
        // Show loading state
        subcategorySelect.innerHTML = '<option value="">جاري التحميل...</option>';
        subcategorySelect.disabled = true;
        
        if (!categoryId) {
            subcategorySelect.innerHTML = '<option value="">-- بدون تصنيف فرعي --</option>';
            subcategorySelect.disabled = false;
            return;
        }
        
        try {
            const response = await fetch(`${this.config.apiBaseUrl}/GetSubcategories?categoryId=${categoryId}`);
            
            if (!response.ok) {
                throw new Error('Failed to load subcategories');
            }
            
            const subcategories = await response.json();
            
            subcategorySelect.innerHTML = '<option value="">-- بدون تصنيف فرعي --</option>';
            
            if (subcategories && subcategories.length > 0) {
                subcategories.forEach(sub => {
                    const option = document.createElement('option');
                    option.value = sub.id;
                    option.textContent = sub.name;
                    subcategorySelect.appendChild(option);
                });
            }
            
            subcategorySelect.disabled = false;
        } catch (error) {
            console.error('Error loading subcategories:', error);
            subcategorySelect.innerHTML = '<option value="">-- حدث خطأ --</option>';
            subcategorySelect.disabled = false;
        }
    },

    /**
     * Save a new category
     */
    saveCategory: async function() {
        const nameInput = document.getElementById('newCategoryName');
        const descriptionInput = document.getElementById('newCategoryDescription');
        const iconInput = document.getElementById('newCategoryIcon');
        const saveBtn = document.getElementById('btnSaveCategory');
        
        const name = nameInput?.value?.trim();
        const description = descriptionInput?.value?.trim();
        const icon = iconInput?.value?.trim() || 'book';
        
        // Validate
        if (!name) {
            this.showFieldError('newCategoryName', 'categoryNameError', 'يرجى إدخال اسم التصنيف');
            nameInput?.focus();
            return;
        }
        
        if (name.length < 2) {
            this.showFieldError('newCategoryName', 'categoryNameError', 'اسم التصنيف يجب أن يكون حرفين على الأقل');
            nameInput?.focus();
            return;
        }
        
        // Get anti-forgery token
        const token = this.getAntiForgeryToken();
        if (!token) {
            this.showError('خطأ في التحقق من الأمان. يرجى تحديث الصفحة.');
            return;
        }
        
        // Show loading state
        this.setButtonLoading(saveBtn, true);
        
        try {
            const response = await fetch(`${this.config.apiBaseUrl}/AddCategory`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token
                },
                body: JSON.stringify({
                    name: name,
                    description: description,
                    icon: icon
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Add new option to category select
                this.addOptionToSelect(
                    this.config.categorySelectId, 
                    result.category.id, 
                    result.category.name,
                    true // select it
                );
                
                // Trigger change event to update subcategories
                const categorySelect = document.getElementById(this.config.categorySelectId);
                if (categorySelect) {
                    categorySelect.dispatchEvent(new Event('change'));
                }
                
                // Close modal
                this.closeModal('addCategoryModal');
                
                // Reset form
                this.resetCategoryForm();
                
                // Show success message
                this.showSuccess('تم إضافة التصنيف بنجاح');
                
                // Callback
                if (typeof this.config.onCategoryAdded === 'function') {
                    this.config.onCategoryAdded(result.category);
                }
            } else {
                this.showFieldError('newCategoryName', 'categoryNameError', result.message || 'فشل إضافة التصنيف');
            }
        } catch (error) {
            console.error('Error adding category:', error);
            this.showError('حدث خطأ أثناء إضافة التصنيف');
        } finally {
            this.setButtonLoading(saveBtn, false);
        }
    },

    /**
     * Save a new subcategory
     */
    saveSubcategory: async function() {
        const parentIdInput = document.getElementById('parentCategoryId');
        const nameInput = document.getElementById('newSubcategoryName');
        const descriptionInput = document.getElementById('newSubcategoryDescription');
        const saveBtn = document.getElementById('btnSaveSubcategory');
        
        const parentId = parentIdInput?.value;
        const name = nameInput?.value?.trim();
        const description = descriptionInput?.value?.trim();
        
        // Validate
        if (!parentId) {
            this.showError('يرجى اختيار التصنيف الرئيسي أولاً');
            return;
        }
        
        if (!name) {
            this.showFieldError('newSubcategoryName', 'subcategoryNameError', 'يرجى إدخال اسم التصنيف الفرعي');
            nameInput?.focus();
            return;
        }
        
        if (name.length < 2) {
            this.showFieldError('newSubcategoryName', 'subcategoryNameError', 'اسم التصنيف الفرعي يجب أن يكون حرفين على الأقل');
            nameInput?.focus();
            return;
        }
        
        // Get anti-forgery token
        const token = this.getAntiForgeryToken();
        if (!token) {
            this.showError('خطأ في التحقق من الأمان. يرجى تحديث الصفحة.');
            return;
        }
        
        // Show loading state
        this.setButtonLoading(saveBtn, true);
        
        try {
            const response = await fetch(`${this.config.apiBaseUrl}/AddSubcategory`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token
                },
                body: JSON.stringify({
                    parentCategoryId: parseInt(parentId),
                    name: name,
                    description: description
                })
            });
            
            const result = await response.json();
            
            if (result.success) {
                // Add new option to subcategory select
                this.addOptionToSelect(
                    this.config.subcategorySelectId,
                    result.subcategory.id,
                    result.subcategory.name,
                    true // select it
                );
                
                // Close modal
                this.closeModal('addSubcategoryModal');
                
                // Reset form
                this.resetSubcategoryForm();
                
                // Show success message
                this.showSuccess('تم إضافة التصنيف الفرعي بنجاح');
                
                // Callback
                if (typeof this.config.onSubcategoryAdded === 'function') {
                    this.config.onSubcategoryAdded(result.subcategory);
                }
            } else {
                this.showFieldError('newSubcategoryName', 'subcategoryNameError', result.message || 'فشل إضافة التصنيف الفرعي');
            }
        } catch (error) {
            console.error('Error adding subcategory:', error);
            this.showError('حدث خطأ أثناء إضافة التصنيف الفرعي');
        } finally {
            this.setButtonLoading(saveBtn, false);
        }
    },

    /**
     * Add an option to a select element
     * @param {string} selectId - The select element ID
     * @param {number|string} value - The option value
     * @param {string} text - The option text
     * @param {boolean} select - Whether to select the new option
     */
    addOptionToSelect: function(selectId, value, text, select = false) {
        const selectElement = document.getElementById(selectId);
        if (!selectElement) return;
        
        const option = document.createElement('option');
        option.value = value;
        option.textContent = text;
        selectElement.appendChild(option);
        
        if (select) {
            selectElement.value = value;
        }
    },

    /**
     * Get the anti-forgery token from the page
     * @returns {string|null} The token value
     */
    getAntiForgeryToken: function() {
        const tokenInput = document.querySelector('[name="__RequestVerificationToken"]');
        return tokenInput?.value || null;
    },

    /**
     * Close a Bootstrap modal
     * @param {string} modalId - The modal element ID
     */
    closeModal: function(modalId) {
        const modalElement = document.getElementById(modalId);
        if (modalElement) {
            const modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
            }
        }
    },

    /**
     * Reset the category form
     */
    resetCategoryForm: function() {
        const nameInput = document.getElementById('newCategoryName');
        const descriptionInput = document.getElementById('newCategoryDescription');
        const iconInput = document.getElementById('newCategoryIcon');
        const iconPreview = document.getElementById('categoryIconPreview');
        
        if (nameInput) {
            nameInput.value = '';
            nameInput.classList.remove('is-invalid');
        }
        if (descriptionInput) descriptionInput.value = '';
        if (iconInput) iconInput.value = 'book';
        if (iconPreview) iconPreview.className = 'feather-book';
        
        this.hideFieldError('categoryNameError');
    },

    /**
     * Reset the subcategory form
     */
    resetSubcategoryForm: function() {
        const nameInput = document.getElementById('newSubcategoryName');
        const descriptionInput = document.getElementById('newSubcategoryDescription');
        
        if (nameInput) {
            nameInput.value = '';
            nameInput.classList.remove('is-invalid');
        }
        if (descriptionInput) descriptionInput.value = '';
        
        this.hideFieldError('subcategoryNameError');
    },

    /**
     * Set button loading state
     * @param {HTMLElement} button - The button element
     * @param {boolean} loading - Whether to show loading state
     */
    setButtonLoading: function(button, loading) {
        if (!button) return;
        
        const textSpan = button.querySelector('.btn-text');
        const loadingSpan = button.querySelector('.btn-loading');
        
        if (loading) {
            button.disabled = true;
            if (textSpan) textSpan.classList.add('d-none');
            if (loadingSpan) loadingSpan.classList.remove('d-none');
        } else {
            button.disabled = false;
            if (textSpan) textSpan.classList.remove('d-none');
            if (loadingSpan) loadingSpan.classList.add('d-none');
        }
    },

    /**
     * Show a field-specific error
     * @param {string} inputId - The input element ID
     * @param {string} errorId - The error message element ID
     * @param {string} message - The error message
     */
    showFieldError: function(inputId, errorId, message) {
        const input = document.getElementById(inputId);
        const errorElement = document.getElementById(errorId);
        
        if (input) input.classList.add('is-invalid');
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.style.display = 'block';
        }
    },

    /**
     * Hide a field error
     * @param {string} errorId - The error message element ID
     */
    hideFieldError: function(errorId) {
        const errorElement = document.getElementById(errorId);
        if (errorElement) {
            errorElement.textContent = '';
            errorElement.style.display = 'none';
        }
    },

    /**
     * Show a success toast notification
     * @param {string} message - The success message
     */
    showSuccess: function(message) {
        // Try to use the project's existing toast function
        if (typeof showToast === 'function') {
            showToast(message, 'success');
        } else if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'success',
                title: 'نجاح',
                text: message,
                timer: 2000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else if (typeof toastr !== 'undefined') {
            toastr.success(message);
        } else {
            // Fallback to a simple notification
            this.showSimpleNotification(message, 'success');
        }
    },

    /**
     * Show an error toast notification
     * @param {string} message - The error message
     */
    showError: function(message) {
        // Try to use the project's existing toast function
        if (typeof showToast === 'function') {
            showToast(message, 'error');
        } else if (typeof Swal !== 'undefined') {
            Swal.fire({
                icon: 'error',
                title: 'خطأ',
                text: message,
                timer: 3000,
                showConfirmButton: false,
                toast: true,
                position: 'top-end'
            });
        } else if (typeof toastr !== 'undefined') {
            toastr.error(message);
        } else {
            // Fallback
            this.showSimpleNotification(message, 'error');
            
            // Callback
            if (typeof this.config.onError === 'function') {
                this.config.onError(message);
            }
        }
    },

    /**
     * Show a simple notification (fallback)
     * @param {string} message - The message
     * @param {string} type - The notification type (success/error)
     */
    showSimpleNotification: function(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} alert-dismissible fade show position-fixed`;
        notification.style.cssText = 'top: 20px; left: 50%; transform: translateX(-50%); z-index: 9999; min-width: 300px;';
        notification.innerHTML = `
            <i class="feather-${type === 'success' ? 'check-circle' : 'alert-circle'} me-2"></i>
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    },

    /**
     * Trigger loading of subcategories for an already-selected category
     * Useful when editing existing items
     * @param {number|string} categoryId - The category ID
     * @param {number|string} selectedSubcategoryId - The subcategory ID to pre-select
     */
    loadAndSelectSubcategory: async function(categoryId, selectedSubcategoryId) {
        if (!categoryId) return;
        
        await this.loadSubcategories(categoryId);
        
        if (selectedSubcategoryId) {
            const subcategorySelect = document.getElementById(this.config.subcategorySelectId);
            if (subcategorySelect) {
                subcategorySelect.value = selectedSubcategoryId;
            }
        }
    }
};

// Make it globally available
window.InstructorCategoryManager = InstructorCategoryManager;

