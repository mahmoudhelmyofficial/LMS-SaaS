/**
 * Instructor Profile Settings JavaScript Module
 * Enterprise-level implementation for dynamic profile management
 */

// Profile API Base URL
const PROFILE_API = '/api/instructor/profile';

// Utility functions
const API = {
    async get(endpoint) {
        try {
            const response = await fetch(`${PROFILE_API}${endpoint}`);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    async post(endpoint, data, isFormData = false) {
        try {
            const options = {
                method: 'POST',
                headers: isFormData ? {} : { 'Content-Type': 'application/json' },
                body: isFormData ? data : JSON.stringify(data)
            };
            const response = await fetch(`${PROFILE_API}${endpoint}`, options);
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    },

    async delete(endpoint) {
        try {
            const response = await fetch(`${PROFILE_API}${endpoint}`, { method: 'DELETE' });
            return await response.json();
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
};

// Toast notification helper
const Toast = {
    show(message, type = 'info') {
        // Use existing toast library or create a simple one
        if (typeof Toastify !== 'undefined') {
            Toastify({
                text: message,
                duration: 3000,
                gravity: 'top',
                position: 'left',
                style: {
                    background: type === 'success' ? '#28a745' : 
                               type === 'error' ? '#dc3545' : 
                               type === 'warning' ? '#ffc107' : '#17a2b8'
                }
            }).showToast();
        } else {
            // Fallback to alert
            alert(message);
        }
    },
    success(message) { this.show(message, 'success'); },
    error(message) { this.show(message, 'error'); },
    warning(message) { this.show(message, 'warning'); },
    info(message) { this.show(message, 'info'); }
};

// Profile Picture Upload
const ProfilePicture = {
    dropzone: null,

    init(container) {
        const dropzone = document.querySelector(container);
        if (!dropzone) return;

        this.dropzone = dropzone;
        this.setupDragAndDrop();
        this.setupFileInput();
    },

    setupDragAndDrop() {
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            this.dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            this.dropzone.addEventListener(eventName, () => {
                this.dropzone.classList.add('drag-over');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            this.dropzone.addEventListener(eventName, () => {
                this.dropzone.classList.remove('drag-over');
            });
        });

        this.dropzone.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFile(files[0]);
            }
        });
    },

    setupFileInput() {
        const input = this.dropzone.querySelector('input[type="file"]');
        if (input) {
            input.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    this.handleFile(e.target.files[0]);
                }
            });
        }
    },

    async handleFile(file) {
        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedTypes.includes(file.type)) {
            Toast.error('نوع الملف غير مسموح. الأنواع المسموحة: JPG, PNG, WebP');
            return;
        }

        // Validate file size (5MB max)
        if (file.size > 5 * 1024 * 1024) {
            Toast.error('حجم الملف يجب ألا يتجاوز 5 ميجابايت');
            return;
        }

        // Show preview
        this.showPreview(file);

        // Upload
        try {
            const formData = new FormData();
            formData.append('file', file);

            const result = await API.post('/upload-picture', formData, true);

            if (result.success) {
                Toast.success('تم رفع الصورة بنجاح');
                this.updatePreview(result.url);
            } else {
                Toast.error(result.message || 'حدث خطأ أثناء رفع الصورة');
            }
        } catch (error) {
            Toast.error('حدث خطأ أثناء رفع الصورة');
        }
    },

    showPreview(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const preview = this.dropzone.querySelector('.preview-image');
            if (preview) {
                preview.src = e.target.result;
                preview.classList.remove('d-none');
            }
        };
        reader.readAsDataURL(file);
    },

    updatePreview(url) {
        const preview = this.dropzone.querySelector('.preview-image');
        if (preview) {
            preview.src = url;
        }
    },

    async delete() {
        if (!confirm('هل أنت متأكد من حذف الصورة؟')) return;

        try {
            const result = await API.delete('/delete-picture');
            if (result.success) {
                Toast.success('تم حذف الصورة بنجاح');
                location.reload();
            } else {
                Toast.error(result.message || 'حدث خطأ أثناء حذف الصورة');
            }
        } catch (error) {
            Toast.error('حدث خطأ أثناء حذف الصورة');
        }
    }
};

// Payment Settings
const PaymentSettings = {
    init() {
        this.bindPaymentMethodChange();
        this.loadPaymentMethods();
    },

    bindPaymentMethodChange() {
        const methodSelect = document.querySelector('[name="PayoutMethod"]');
        if (!methodSelect) return;

        methodSelect.addEventListener('change', (e) => {
            this.showPaymentFields(e.target.value);
            this.loadPaymentInfo(e.target.value);
        });

        // Initialize with current value
        this.showPaymentFields(methodSelect.value);
    },

    showPaymentFields(method) {
        // Hide all payment detail sections
        document.querySelectorAll('.payment-section').forEach(section => {
            section.classList.add('d-none');
        });

        // Show relevant section
        const sectionMap = {
            'PayPal': '.paypal-section',
            'BankTransfer': '.bank-section',
            'VodafoneCash': '.mobile-wallet-section',
            'InstaPay': '.mobile-wallet-section',
            'OrangeMoney': '.mobile-wallet-section',
            'Wise': '.wise-section',
            'Stripe': '.stripe-section'
        };

        const sectionSelector = sectionMap[method];
        if (sectionSelector) {
            const section = document.querySelector(sectionSelector);
            if (section) {
                section.classList.remove('d-none');
            }
        }
    },

    async loadPaymentMethods(countryCode = null) {
        try {
            const methods = await API.get(`/payment-methods${countryCode ? `?countryCode=${countryCode}` : ''}`);
            // Methods loaded successfully
            console.log('Payment methods loaded:', methods);
        } catch (error) {
            console.error('Error loading payment methods:', error);
        }
    },

    async loadPaymentInfo(method) {
        try {
            const [limits, fees, times] = await Promise.all([
                API.get(`/withdrawal-limits/${method}`),
                API.get(`/payment-fees/${method}`),
                API.get(`/processing-times/${method}`)
            ]);

            this.updatePaymentInfo(limits, fees, times);
        } catch (error) {
            console.error('Error loading payment info:', error);
        }
    },

    updatePaymentInfo(limits, fees, times) {
        // Update info displays
        const infoContainer = document.querySelector('.payment-info');
        if (!infoContainer) return;

        let html = '';
        
        if (limits) {
            html += `<div class="mb-2"><strong>الحد الأدنى:</strong> ${limits.minimumAmount} ${limits.currency}</div>`;
            html += `<div class="mb-2"><strong>الحد الأقصى:</strong> ${limits.maximumAmount} ${limits.currency}</div>`;
        }

        if (fees) {
            html += `<div class="mb-2"><strong>الرسوم:</strong> ${fees.descriptionAr}</div>`;
        }

        if (times) {
            html += `<div><strong>وقت المعالجة:</strong> ${times.displayTextAr}</div>`;
        }

        infoContainer.innerHTML = html;
    },

    async validate() {
        const method = document.querySelector('[name="PayoutMethod"]')?.value;
        const data = this.collectFormData();

        try {
            const result = await API.post('/validate-payment', {
                paymentMethod: method,
                ...data
            });

            if (result.success) {
                Toast.success('البيانات صحيحة');
            } else {
                Toast.error(result.message || 'البيانات غير صحيحة');
            }
        } catch (error) {
            Toast.error('حدث خطأ أثناء التحقق');
        }
    },

    collectFormData() {
        const form = document.querySelector('#paymentSettingsForm');
        if (!form) return {};

        const formData = new FormData(form);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        return data;
    }
};

// Dynamic Dropdowns
const DynamicDropdowns = {
    async loadCities(countryCode) {
        try {
            const cities = await API.get(`/cities/${countryCode}`);
            const select = document.querySelector('[name="City"]');
            if (select) {
                select.innerHTML = cities.map(c => 
                    `<option value="${c.value}">${c.text}</option>`
                ).join('');
            }
        } catch (error) {
            console.error('Error loading cities:', error);
        }
    },

    async loadBanks(countryCode) {
        try {
            const banks = await API.get(`/banks/${countryCode}`);
            const select = document.querySelector('[name="BankName"]');
            if (select) {
                select.innerHTML = banks.map(b => 
                    `<option value="${b.value}">${b.text}</option>`
                ).join('');
            }
        } catch (error) {
            console.error('Error loading banks:', error);
        }
    },

    async loadWalletProviders(countryCode) {
        try {
            const providers = await API.get(`/wallet-providers/${countryCode}`);
            const select = document.querySelector('[name="MobileWalletProvider"]');
            if (select) {
                select.innerHTML = providers.map(p => 
                    `<option value="${p.value}">${p.text}</option>`
                ).join('');
            }
        } catch (error) {
            console.error('Error loading wallet providers:', error);
        }
    },

    init() {
        const countrySelect = document.querySelector('[name="Country"]');
        if (countrySelect) {
            countrySelect.addEventListener('change', (e) => {
                const code = e.target.value;
                this.loadCities(code);
                this.loadBanks(code);
                this.loadWalletProviders(code);
            });
        }
    }
};

// Profile Completeness
const ProfileCompleteness = {
    async load() {
        try {
            const data = await API.get('/completeness');
            this.render(data);
        } catch (error) {
            console.error('Error loading profile completeness:', error);
        }
    },

    render(data) {
        const container = document.querySelector('.profile-completeness');
        if (!container) return;

        // Update progress bar
        const progressBar = container.querySelector('.progress-bar');
        if (progressBar) {
            progressBar.style.width = `${data.score}%`;
            progressBar.textContent = `${data.score}%`;
        }

        // Update recommendations
        const recContainer = container.querySelector('.recommendations');
        if (recContainer && data.recommendations) {
            recContainer.innerHTML = data.recommendations.map(r => 
                `<li class="text-muted">${r}</li>`
            ).join('');
        }
    }
};

// Qualifications Management
const Qualifications = {
    async load() {
        try {
            const data = await API.get('/qualifications');
            this.render(data);
        } catch (error) {
            console.error('Error loading qualifications:', error);
        }
    },

    render(qualifications) {
        const container = document.querySelector('.qualifications-list');
        if (!container) return;

        if (!qualifications || qualifications.length === 0) {
            container.innerHTML = '<p class="text-muted">لا توجد مؤهلات مضافة</p>';
            return;
        }

        container.innerHTML = qualifications.map(q => `
            <div class="qualification-item d-flex justify-content-between align-items-center p-3 border rounded mb-2" data-id="${q.id}">
                <div>
                    <h6 class="mb-1">${q.title}</h6>
                    <small class="text-muted">${q.institution || ''} ${q.year ? `(${q.year})` : ''}</small>
                    ${q.isVerified ? '<span class="badge bg-success ms-2">مُحقق</span>' : ''}
                </div>
                <div class="btn-group">
                    <button type="button" class="btn btn-sm btn-light" onclick="Qualifications.edit(${q.id})">
                        <i class="feather-edit-2"></i>
                    </button>
                    <button type="button" class="btn btn-sm btn-light text-danger" onclick="Qualifications.delete(${q.id})">
                        <i class="feather-trash-2"></i>
                    </button>
                </div>
            </div>
        `).join('');
    },

    async add(data) {
        try {
            const result = await API.post('/qualifications', data);
            if (result.success) {
                Toast.success('تم إضافة المؤهل بنجاح');
                this.load();
                this.closeModal();
            } else {
                Toast.error(result.message || 'حدث خطأ أثناء إضافة المؤهل');
            }
        } catch (error) {
            Toast.error('حدث خطأ أثناء إضافة المؤهل');
        }
    },

    edit(id) {
        // Open edit modal with qualification data
        console.log('Edit qualification:', id);
    },

    async delete(id) {
        if (!confirm('هل أنت متأكد من حذف هذا المؤهل؟')) return;

        try {
            const result = await API.delete(`/qualifications/${id}`);
            if (result.success) {
                Toast.success('تم حذف المؤهل بنجاح');
                this.load();
            } else {
                Toast.error(result.message || 'حدث خطأ أثناء حذف المؤهل');
            }
        } catch (error) {
            Toast.error('حدث خطأ أثناء حذف المؤهل');
        }
    },

    closeModal() {
        const modal = document.querySelector('#addQualificationModal');
        if (modal) {
            const bsModal = bootstrap.Modal.getInstance(modal);
            if (bsModal) bsModal.hide();
        }
    }
};

// Username Availability Checker
const UsernameChecker = {
    timeout: null,

    init() {
        const input = document.querySelector('[name="Username"]');
        if (!input) return;

        input.addEventListener('input', (e) => {
            clearTimeout(this.timeout);
            this.timeout = setTimeout(() => {
                this.check(e.target.value);
            }, 500);
        });
    },

    async check(username) {
        if (!username || username.length < 3) return;

        try {
            const result = await API.get(`/check-username?username=${encodeURIComponent(username)}`);
            const input = document.querySelector('[name="Username"]');
            const feedback = input?.nextElementSibling;

            if (result.available) {
                input?.classList.remove('is-invalid');
                input?.classList.add('is-valid');
                if (feedback) feedback.textContent = 'اسم المستخدم متاح';
            } else {
                input?.classList.remove('is-valid');
                input?.classList.add('is-invalid');
                if (feedback) feedback.textContent = 'اسم المستخدم مستخدم بالفعل';
            }
        } catch (error) {
            console.error('Error checking username:', error);
        }
    }
};

// Form Auto-Save (Draft)
const AutoSave = {
    key: 'instructor_profile_draft',
    interval: null,

    init(formSelector) {
        const form = document.querySelector(formSelector);
        if (!form) return;

        this.form = form;
        this.loadDraft();
        this.startAutoSave();

        form.addEventListener('submit', () => {
            this.clearDraft();
        });
    },

    loadDraft() {
        try {
            const draft = localStorage.getItem(this.key);
            if (draft) {
                const data = JSON.parse(draft);
                const age = Date.now() - data.timestamp;
                
                // Only restore drafts less than 1 hour old
                if (age < 3600000) {
                    if (confirm('لديك مسودة محفوظة. هل تريد استعادتها؟')) {
                        this.restoreData(data.values);
                    } else {
                        this.clearDraft();
                    }
                }
            }
        } catch (error) {
            console.error('Error loading draft:', error);
        }
    },

    restoreData(values) {
        Object.keys(values).forEach(key => {
            const input = this.form.querySelector(`[name="${key}"]`);
            if (input) {
                input.value = values[key];
            }
        });
    },

    saveDraft() {
        if (!this.form) return;

        const formData = new FormData(this.form);
        const values = {};
        formData.forEach((value, key) => {
            if (!key.includes('Token')) { // Don't save anti-forgery tokens
                values[key] = value;
            }
        });

        const draft = {
            timestamp: Date.now(),
            values: values
        };

        localStorage.setItem(this.key, JSON.stringify(draft));
    },

    startAutoSave() {
        this.interval = setInterval(() => {
            this.saveDraft();
        }, 30000); // Save every 30 seconds
    },

    clearDraft() {
        localStorage.removeItem(this.key);
        if (this.interval) {
            clearInterval(this.interval);
        }
    }
};

// Character Counter
const CharCounter = {
    init() {
        document.querySelectorAll('[data-char-count]').forEach(input => {
            const maxLength = input.getAttribute('maxlength') || input.dataset.charCount;
            this.createCounter(input, maxLength);
            
            input.addEventListener('input', () => {
                this.updateCounter(input, maxLength);
            });
        });
    },

    createCounter(input, maxLength) {
        const counter = document.createElement('div');
        counter.className = 'char-counter text-muted fs-12 text-end mt-1';
        counter.textContent = `0 / ${maxLength}`;
        input.parentNode.appendChild(counter);
        input._counter = counter;
    },

    updateCounter(input, maxLength) {
        const counter = input._counter;
        if (counter) {
            const length = input.value.length;
            counter.textContent = `${length} / ${maxLength}`;
            
            if (length > maxLength * 0.9) {
                counter.classList.add('text-warning');
            } else {
                counter.classList.remove('text-warning');
            }
        }
    }
};

// URL Validator
const URLValidator = {
    init() {
        document.querySelectorAll('input[type="url"]').forEach(input => {
            input.addEventListener('blur', () => {
                this.validate(input);
            });
        });
    },

    validate(input) {
        const value = input.value.trim();
        if (!value) {
            input.classList.remove('is-valid', 'is-invalid');
            return true;
        }

        try {
            const url = new URL(value);
            if (['http:', 'https:'].includes(url.protocol)) {
                input.classList.remove('is-invalid');
                input.classList.add('is-valid');
                return true;
            }
        } catch (e) {
            // Invalid URL
        }

        input.classList.remove('is-valid');
        input.classList.add('is-invalid');
        return false;
    }
};

// Initialize on document ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize modules based on page
    if (document.querySelector('#profilePictureDropzone')) {
        ProfilePicture.init('#profilePictureDropzone');
    }

    if (document.querySelector('[name="PayoutMethod"]')) {
        PaymentSettings.init();
    }

    DynamicDropdowns.init();
    UsernameChecker.init();
    CharCounter.init();
    URLValidator.init();

    // Load profile completeness if widget exists
    if (document.querySelector('.profile-completeness')) {
        ProfileCompleteness.load();
    }

    // Load qualifications if section exists
    if (document.querySelector('.qualifications-list')) {
        Qualifications.load();
    }

    // Initialize auto-save for edit forms
    if (document.querySelector('#editProfileForm')) {
        AutoSave.init('#editProfileForm');
    }
});

// Export for global access
window.ProfilePicture = ProfilePicture;
window.PaymentSettings = PaymentSettings;
window.Qualifications = Qualifications;
window.ProfileCompleteness = ProfileCompleteness;


