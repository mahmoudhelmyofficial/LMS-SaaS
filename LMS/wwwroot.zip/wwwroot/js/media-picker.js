/**
 * Media Picker Component
 * Enterprise-level media management for instructor dashboard
 */
const MediaPicker = (function () {
    // State
    let currentPickerId = null;
    let currentMediaType = 'All';
    let currentPage = 1;
    let hasMore = false;
    let selectedMedia = null;
    let uploadedMedia = null;
    let searchTimeout = null;
    let modal = null;
    let isInitialized = false;
    let externalPickers = {};

    // URLs
    const API_URLS = {
        getItems: '/Instructor/MediaLibrary/GetMediaItems',
        upload: '/Instructor/MediaLibrary/UploadApi',
        delete: '/Instructor/MediaLibrary/DeleteApi'
    };

    /**
     * Initialize the media picker
     */
    function init() {
        // Singleton enforcement - prevent double initialization
        if (isInitialized) {
            console.log('MediaPicker already initialized');
            return;
        }
        
        // Initialize modal
        const modalEl = document.getElementById('mediaPickerModal');
        if (modalEl) {
            // Check if modal instance already exists to prevent duplicates
            const existingModal = bootstrap.Modal.getInstance(modalEl);
            if (existingModal) {
                modal = existingModal;
            } else {
                modal = new bootstrap.Modal(modalEl, {
                    backdrop: 'static',
                    keyboard: false
                });
            }
            
            // Event listeners
            modalEl.addEventListener('hidden.bs.modal', resetModal);
            
            // Ensure proper z-index when modal shows
            modalEl.addEventListener('show.bs.modal', function() {
                // Set z-index for proper stacking
                this.style.zIndex = '1060';
                // Handle backdrop z-index
                setTimeout(() => {
                    const backdrop = document.querySelector('.modal-backdrop');
                    if (backdrop) {
                        backdrop.style.zIndex = '1059';
                    }
                }, 10);
            });
            
            isInitialized = true;
            
            // Filter buttons
            document.querySelectorAll('#mediaTypeFilter button').forEach(btn => {
                btn.addEventListener('click', function() {
                    document.querySelectorAll('#mediaTypeFilter button').forEach(b => b.classList.remove('active'));
                    this.classList.add('active');
                    currentMediaType = this.dataset.type;
                    currentPage = 1;
                    loadMediaItems();
                });
            });
            
            // Search input
            const searchInput = document.getElementById('mediaSearchInput');
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    clearTimeout(searchTimeout);
                    searchTimeout = setTimeout(() => {
                        currentPage = 1;
                        loadMediaItems();
                    }, 300);
                });
            }
            
            // Upload dropzone
            initUploadDropzone();
        }
    }

    /**
     * Initialize upload dropzone
     */
    function initUploadDropzone() {
        const dropzone = document.getElementById('uploadDropzone');
        const fileInput = document.getElementById('uploadFileInput');
        
        if (!dropzone || !fileInput) return;
        
        // Prevent file input click from bubbling and triggering modal behaviors
        fileInput.addEventListener('click', (e) => {
            e.stopPropagation();
        });
        
        // Click to browse - with proper event handling to prevent popup issues
        dropzone.addEventListener('click', (e) => {
            e.stopPropagation();
            e.preventDefault();
            
            // Only trigger file input if not clicking a button or input
            if (e.target.tagName !== 'BUTTON' && e.target.tagName !== 'INPUT' && !e.target.closest('button')) {
                // Use setTimeout to break the event chain and prevent modal interference
                setTimeout(() => {
                    fileInput.click();
                }, 0);
            }
        });
        
        // Drag and drop
        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, preventDefaults, false);
        });
        
        function preventDefaults(e) {
            e.preventDefault();
            e.stopPropagation();
        }
        
        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, () => dropzone.classList.add('dragover'), false);
        });
        
        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, () => dropzone.classList.remove('dragover'), false);
        });
        
        dropzone.addEventListener('drop', (e) => {
            e.stopPropagation();
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                handleFileSelect(files[0]);
            }
        });
        
        // File input change - prevent bubbling
        fileInput.addEventListener('change', (e) => {
            e.stopPropagation();
            if (e.target.files.length > 0) {
                handleFileSelect(e.target.files[0]);
            }
        });
    }

    /**
     * Handle file selection
     */
    function handleFileSelect(file) {
        // Validate file size (50MB max)
        const maxSize = 50 * 1024 * 1024;
        if (file.size > maxSize) {
            showToast('حجم الملف يتجاوز الحد المسموح (50 MB)', 'error');
            return;
        }
        
        // Show file info form
        const fileInfoEl = document.getElementById('uploadFileInfo');
        const titleInput = document.getElementById('uploadTitleInput');
        if (fileInfoEl) {
            fileInfoEl.classList.remove('d-none');
            // Set default title from filename
            if (titleInput) {
                titleInput.value = file.name.replace(/\.[^/.]+$/, '');
            }
        }
        
        // Upload file
        uploadFile(file);
    }

    /**
     * Upload file to server
     */
    async function uploadFile(file) {
        const progressEl = document.getElementById('uploadProgress');
        const placeholderEl = document.getElementById('uploadPlaceholder');
        const successEl = document.getElementById('uploadSuccess');
        const progressBar = document.getElementById('uploadProgressBar');
        const progressText = document.getElementById('uploadProgressText');
        const fileNameEl = document.getElementById('uploadFileName');
        
        // Show progress
        if (placeholderEl) placeholderEl.classList.add('d-none');
        if (progressEl) progressEl.classList.remove('d-none');
        if (fileNameEl) fileNameEl.textContent = file.name;
        
        const formData = new FormData();
        formData.append('File', file);
        formData.append('Title', document.getElementById('uploadTitleInput')?.value || '');
        formData.append('Description', document.getElementById('uploadDescInput')?.value || '');
        
        // Get anti-forgery token from hidden input (preferred) or form
        const token = document.querySelector('input[name="__RequestVerificationToken"]')?.value;
        
        if (!token) {
            showUploadError('خطأ في التحقق من الأمان. يرجى تحديث الصفحة.');
            return;
        }
        
        try {
            const xhr = new XMLHttpRequest();
            
            xhr.upload.addEventListener('progress', (e) => {
                if (e.lengthComputable) {
                    const percent = Math.round((e.loaded / e.total) * 100);
                    if (progressBar) progressBar.style.width = percent + '%';
                    if (progressText) progressText.textContent = `جاري الرفع... ${percent}%`;
                }
            });
            
            xhr.addEventListener('load', () => {
                if (xhr.status === 200) {
                    try {
                        const response = JSON.parse(xhr.responseText);
                        if (response.success) {
                            uploadedMedia = response.media;
                            if (progressEl) progressEl.classList.add('d-none');
                            if (successEl) successEl.classList.remove('d-none');
                            showToast('تم رفع الملف بنجاح', 'success');
                        } else {
                            showUploadError(response.message || 'فشل رفع الملف');
                        }
                    } catch (parseError) {
                        console.error('Response parse error:', parseError, xhr.responseText);
                        showUploadError('خطأ في معالجة الاستجابة');
                    }
                } else if (xhr.status === 400) {
                    showUploadError('طلب غير صالح. تأكد من صحة البيانات.');
                } else if (xhr.status === 401 || xhr.status === 403) {
                    showUploadError('خطأ في الأمان. يرجى تحديث الصفحة والمحاولة مرة أخرى.');
                } else {
                    showUploadError('خطأ في الاتصال بالخادم (الكود: ' + xhr.status + ')');
                }
            });
            
            xhr.addEventListener('error', () => {
                showUploadError('فشل الاتصال بالخادم');
            });
            
            xhr.open('POST', API_URLS.upload);
            xhr.withCredentials = true; // Include authentication cookies
            // Use X-CSRF-TOKEN header as configured in ASP.NET Core
            xhr.setRequestHeader('X-CSRF-TOKEN', token);
            xhr.send(formData);
            
        } catch (error) {
            showUploadError(error.message);
        }
    }

    /**
     * Show upload error
     */
    function showUploadError(message) {
        showToast(message, 'error');
        resetUpload();
    }

    /**
     * Reset upload form
     */
    function resetUpload() {
        const progressEl = document.getElementById('uploadProgress');
        const placeholderEl = document.getElementById('uploadPlaceholder');
        const successEl = document.getElementById('uploadSuccess');
        const fileInfoEl = document.getElementById('uploadFileInfo');
        const fileInput = document.getElementById('uploadFileInput');
        const progressBar = document.getElementById('uploadProgressBar');
        
        if (progressEl) progressEl.classList.add('d-none');
        if (successEl) successEl.classList.add('d-none');
        if (placeholderEl) placeholderEl.classList.remove('d-none');
        if (fileInfoEl) fileInfoEl.classList.add('d-none');
        if (fileInput) fileInput.value = '';
        if (progressBar) progressBar.style.width = '0%';
        
        uploadedMedia = null;
    }

    /**
     * Use the uploaded file
     */
    function useUploaded() {
        if (uploadedMedia) {
            applySelection(uploadedMedia.fileUrl, uploadedMedia);
            if (modal) modal.hide();
        }
    }

    /**
     * Open media library modal
     */
    function openLibrary(pickerId) {
        currentPickerId = pickerId;
        const pickerEl = document.getElementById('mediaPicker_' + pickerId);
        
        if (pickerEl) {
            // Set media type filter based on picker
            const pickerMediaType = pickerEl.dataset.mediaType || 'All';
            currentMediaType = pickerMediaType;
            
            // Update filter buttons
            document.querySelectorAll('#mediaTypeFilter button').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.type === currentMediaType);
            });
            
            // Hide filter buttons if specific type is required
            const filterEl = document.getElementById('mediaTypeFilter');
            if (filterEl) {
                filterEl.style.display = pickerMediaType === 'All' ? 'flex' : 'none';
            }
        }
        
        currentPage = 1;
        selectedMedia = null;
        loadMediaItems();
        
        // Switch to library tab
        document.getElementById('libraryTab')?.click();
        
        if (modal) modal.show();
    }

    /**
     * Open upload tab directly
     */
    function openUpload(pickerId) {
        currentPickerId = pickerId;
        resetUpload();
        
        // Switch to upload tab
        document.getElementById('uploadTab')?.click();
        
        if (modal) modal.show();
    }

    /**
     * Load media items from server
     */
    async function loadMediaItems(append = false) {
        const gridEl = document.getElementById('mediaGrid');
        const loadingEl = document.getElementById('mediaLoading');
        const emptyEl = document.getElementById('mediaEmpty');
        const loadMoreContainer = document.getElementById('loadMoreContainer');
        
        if (!append) {
            if (gridEl) gridEl.innerHTML = '';
            if (loadingEl) loadingEl.classList.remove('d-none');
        }
        if (emptyEl) emptyEl.classList.add('d-none');
        
        const searchQuery = document.getElementById('mediaSearchInput')?.value || '';
        
        try {
            const params = new URLSearchParams({
                mediaType: currentMediaType,
                search: searchQuery,
                page: currentPage,
                pageSize: 20
            });
            
            const response = await fetch(`${API_URLS.getItems}?${params}`, {
                credentials: 'same-origin'
            });
            const data = await response.json();
            
            if (loadingEl) loadingEl.classList.add('d-none');
            
            if (data.success) {
                hasMore = data.hasMore;
                
                if (data.items.length === 0 && !append) {
                    if (emptyEl) emptyEl.classList.remove('d-none');
                } else {
                    renderMediaItems(data.items, append);
                }
                
                if (loadMoreContainer) {
                    loadMoreContainer.classList.toggle('d-none', !hasMore);
                }
            }
        } catch (error) {
            if (loadingEl) loadingEl.classList.add('d-none');
            showToast('خطأ في تحميل الملفات', 'error');
        }
    }

    /**
     * Render media items in grid
     */
    function renderMediaItems(items, append = false) {
        const gridEl = document.getElementById('mediaGrid');
        if (!gridEl) return;
        
        if (!append) {
            gridEl.innerHTML = '';
        }
        
        items.forEach(item => {
            const col = document.createElement('div');
            col.className = 'col-6 col-md-4 col-lg-3';
            
            const isImage = item.mediaType === 'Image';
            const thumbUrl = item.thumbnailUrl || item.fileUrl;
            
            col.innerHTML = `
                <div class="media-item card h-100" data-id="${item.id}" data-url="${item.fileUrl}" onclick="MediaPicker.selectItem(this)">
                    <div class="card-body p-2">
                        ${isImage ? `
                            <img src="${thumbUrl}" alt="${item.title}" class="media-thumb rounded w-100 mb-2">
                        ` : `
                            <div class="media-type-icon ${item.mediaType.toLowerCase()} rounded mb-2">
                                <i class="feather-${getMediaIcon(item.mediaType)}"></i>
                            </div>
                        `}
                        <h6 class="card-title small mb-1 text-truncate" title="${item.title}">${item.title}</h6>
                        <p class="card-text small text-muted mb-0">${item.formattedSize}</p>
                    </div>
                </div>
            `;
            
            gridEl.appendChild(col);
        });
    }

    /**
     * Get icon for media type
     */
    function getMediaIcon(mediaType) {
        const icons = {
            'Image': 'image',
            'Video': 'video',
            'Audio': 'music',
            'Document': 'file-text',
            'Other': 'file'
        };
        return icons[mediaType] || 'file';
    }

    /**
     * Select a media item
     */
    function selectItem(element) {
        // Deselect all
        document.querySelectorAll('.media-item').forEach(el => el.classList.remove('selected'));
        
        // Select this one
        element.classList.add('selected');
        
        selectedMedia = {
            id: element.dataset.id,
            url: element.dataset.url
        };
        
        // Show select button
        const selectBtn = document.getElementById('selectMediaBtn');
        if (selectBtn) selectBtn.classList.remove('d-none');
    }

    /**
     * Confirm selection and apply to picker
     */
    function confirmSelection() {
        if (selectedMedia) {
            applySelection(selectedMedia.url, selectedMedia);
            if (modal) modal.hide();
        }
    }

    /**
     * Apply selection to the picker field
     */
    function applySelection(url, mediaData) {
        if (!currentPickerId) return;
        
        const pickerEl = document.getElementById('mediaPicker_' + currentPickerId);
        if (!pickerEl) return;
        
        const fieldId = pickerEl.dataset.fieldId;
        const inputEl = document.getElementById(fieldId);
        const previewImgEl = document.getElementById('previewImage_' + currentPickerId);
        const placeholderEl = document.getElementById('placeholder_' + currentPickerId);
        
        // Update hidden input
        if (inputEl) {
            inputEl.value = url;
            inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // Update preview
        if (previewImgEl) {
            previewImgEl.src = url;
            previewImgEl.classList.remove('d-none');
        }
        if (placeholderEl) {
            placeholderEl.classList.add('d-none');
        }
        
        // Add remove button if not exists
        const previewContainer = document.getElementById('preview_' + currentPickerId);
        if (previewContainer && !previewContainer.querySelector('.btn-danger')) {
            const removeBtn = document.createElement('button');
            removeBtn.type = 'button';
            removeBtn.className = 'btn btn-sm btn-danger position-absolute';
            removeBtn.style.cssText = 'top: 8px; left: 8px; z-index: 10;';
            removeBtn.title = 'إزالة';
            removeBtn.innerHTML = '<i class="feather-x"></i>';
            removeBtn.onclick = () => clear(currentPickerId);
            previewContainer.appendChild(removeBtn);
        }
        
        showToast('تم اختيار الملف بنجاح', 'success');
    }

    /**
     * Clear the picker selection
     */
    function clear(pickerId) {
        const pickerEl = document.getElementById('mediaPicker_' + pickerId);
        if (!pickerEl) return;
        
        const fieldId = pickerEl.dataset.fieldId;
        const inputEl = document.getElementById(fieldId);
        const previewImgEl = document.getElementById('previewImage_' + pickerId);
        const placeholderEl = document.getElementById('placeholder_' + pickerId);
        const previewContainer = document.getElementById('preview_' + pickerId);
        
        // Clear hidden input
        if (inputEl) {
            inputEl.value = '';
            inputEl.dispatchEvent(new Event('change', { bubbles: true }));
        }
        
        // Hide preview image
        if (previewImgEl) {
            previewImgEl.src = '';
            previewImgEl.classList.add('d-none');
        }
        
        // Show placeholder
        if (placeholderEl) {
            placeholderEl.classList.remove('d-none');
        }
        
        // Remove the remove button
        if (previewContainer) {
            const removeBtn = previewContainer.querySelector('.btn-danger');
            if (removeBtn) removeBtn.remove();
        }
    }

    /**
     * Load more items
     */
    function loadMore() {
        if (hasMore) {
            currentPage++;
            loadMediaItems(true);
        }
    }

    /**
     * Reset modal state
     */
    function resetModal() {
        currentPickerId = null;
        selectedMedia = null;
        uploadedMedia = null;
        
        // Reset selection
        document.querySelectorAll('.media-item').forEach(el => el.classList.remove('selected'));
        
        // Hide select button
        const selectBtn = document.getElementById('selectMediaBtn');
        if (selectBtn) selectBtn.classList.add('d-none');
        
        // Reset upload form
        resetUpload();
        
        // Clear search
        const searchInput = document.getElementById('mediaSearchInput');
        if (searchInput) searchInput.value = '';
    }

    /**
     * Show toast notification
     */
    function showToast(message, type = 'info') {
        // Try to use existing toast system or create simple alert
        if (typeof toastr !== 'undefined') {
            toastr[type](message);
        } else if (typeof Swal !== 'undefined') {
            Swal.fire({
                toast: true,
                position: 'top-end',
                icon: type === 'error' ? 'error' : type === 'success' ? 'success' : 'info',
                title: message,
                showConfirmButton: false,
                timer: 3000
            });
        } else {
            // Simple fallback
            console.log(`[${type}] ${message}`);
        }
    }

    /**
     * Check if the modal is currently open
     */
    function isOpen() {
        const modalEl = document.getElementById('mediaPickerModal');
        if (!modalEl) return false;
        return modalEl.classList.contains('show');
    }

    /**
     * Register an external picker for views with custom implementations
     * @param {string} pickerId - Unique identifier for the picker
     * @param {string} fieldId - ID of the form field to update
     * @param {string} mediaType - Type of media to filter (Image, Video, Audio, Document, All)
     * @param {function} onSelectCallback - Callback function when media is selected
     * @returns {object} - Methods to interact with the picker
     */
    function registerExternalPicker(pickerId, fieldId, mediaType, onSelectCallback) {
        // Store the external picker configuration
        externalPickers[pickerId] = {
            fieldId: fieldId,
            mediaType: mediaType || 'All',
            onSelect: onSelectCallback
        };

        // Create a virtual picker element if needed for compatibility
        if (!document.getElementById('mediaPicker_' + pickerId)) {
            const virtualPicker = document.createElement('div');
            virtualPicker.id = 'mediaPicker_' + pickerId;
            virtualPicker.dataset.fieldId = fieldId;
            virtualPicker.dataset.mediaType = mediaType || 'All';
            virtualPicker.style.display = 'none';
            document.body.appendChild(virtualPicker);
        }

        // Return methods to interact with this picker
        return {
            openLibrary: () => openLibrary(pickerId),
            openUpload: () => openUpload(pickerId),
            clear: () => clear(pickerId),
            getFieldId: () => fieldId,
            getMediaType: () => mediaType
        };
    }

    /**
     * Override applySelection to support external pickers
     */
    const originalApplySelection = applySelection;
    function applySelectionWithExternal(url, mediaData) {
        // Check if this is an external picker
        if (currentPickerId && externalPickers[currentPickerId]) {
            const externalPicker = externalPickers[currentPickerId];
            
            // Update the field if it exists
            const inputEl = document.getElementById(externalPicker.fieldId);
            if (inputEl) {
                inputEl.value = url;
                inputEl.dispatchEvent(new Event('change', { bubbles: true }));
            }

            // Call the callback if provided
            if (typeof externalPicker.onSelect === 'function') {
                externalPicker.onSelect(url, mediaData);
            }

            showToast('تم اختيار الملف بنجاح', 'success');
            return;
        }

        // Fall back to original implementation
        originalApplySelection(url, mediaData);
    }

    // Replace applySelection with the extended version
    // Note: This is done by reassigning in the closure

    // Initialize on DOM ready
    document.addEventListener('DOMContentLoaded', init);

    // Public API
    return {
        openLibrary,
        openUpload,
        selectItem,
        confirmSelection,
        clear,
        loadMore,
        resetUpload,
        useUploaded,
        isOpen,
        registerExternalPicker,
        init, // Expose init for manual re-initialization if needed
        refresh: () => {
            currentPage = 1;
            loadMediaItems();
        }
    };
})();


