/**
 * LMS PWA - Service Worker registration, install prompt, offline UX
 * Runs on every layout so the app is installable from any page.
 */
(function () {
    'use strict';

    if (!('serviceWorker' in navigator)) return;

    window.addEventListener('load', function () {
        navigator.serviceWorker.register('/sw.js', { scope: '/' })
            .then(function (reg) {
                reg.onupdatefound = function () {
                    var installing = reg.installing;
                    if (!installing) return;
                    installing.onstatechange = function () {
                        if (installing.state === 'installed' && navigator.serviceWorker.controller) {
                            showUpdateBanner();
                        }
                    };
                };
            })
            .catch(function (err) {
                console.warn('LMS PWA: Service worker registration failed', err);
            });
    });

    var deferredPrompt;
    var installBannerTimer;

    window.addEventListener('beforeinstallprompt', function (e) {
        e.preventDefault();
        deferredPrompt = e;
        // Show after 30s or on first user interaction (scroll/click), whichever comes first
        function maybeShowInstall() {
            if (installBannerTimer) { clearTimeout(installBannerTimer); installBannerTimer = null; }
            if (deferredPrompt) showInstallBanner();
        }
        installBannerTimer = setTimeout(maybeShowInstall, 30000);
        window.addEventListener('scroll', function onceScroll() {
            window.removeEventListener('scroll', onceScroll);
            maybeShowInstall();
        }, { passive: true, once: true });
        document.documentElement.addEventListener('click', function onceClick() {
            document.documentElement.removeEventListener('click', onceClick);
            maybeShowInstall();
        }, { once: true });
    });

    window.addEventListener('appinstalled', function () {
        deferredPrompt = null;
        if (installBannerTimer) clearTimeout(installBannerTimer);
        hideInstallBanner();
        try { localStorage.setItem('lms-pwa-installed', '1'); } catch (x) {}
    });

    function showInstallBanner() {
        if (document.getElementById('lms-pwa-install-banner')) return;
        if (document.getElementById('lms-pwa-update-banner')) return;
        try { if (localStorage.getItem('lms-pwa-installed') || localStorage.getItem('lms-pwa-install-dismissed')) return; } catch (x) {}
        if (!deferredPrompt) return;

        var banner = document.createElement('div');
        banner.id = 'lms-pwa-install-banner';
        banner.setAttribute('role', 'banner');
        banner.className = 'lms-pwa-banner lms-pwa-banner-install';
        banner.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#002d6b;color:#fff;padding:12px 16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px;z-index:9999;font-family:\'Cairo\',sans-serif;direction:rtl;box-shadow:0 -4px 12px rgba(0,0,0,.15);';
        banner.innerHTML = '<span style="font-weight:600;">تثبيت التطبيق لاستخدامه من الشاشة الرئيسية</span>' +
            '<div style="display:flex;gap:8px;">' +
            '<button type="button" id="lms-pwa-install-btn" style="background:#004aad;color:#fff;border:none;padding:8px 16px;border-radius:6px;font-weight:600;cursor:pointer;font-family:inherit;">تثبيت</button>' +
            '<button type="button" id="lms-pwa-dismiss-btn" style="background:transparent;color:#fff;border:1px solid rgba(255,255,255,.5);padding:8px 16px;border-radius:6px;cursor:pointer;font-family:inherit;">لاحقاً</button>' +
            '</div>';
        document.body.appendChild(banner);
        document.getElementById('lms-pwa-install-btn').addEventListener('click', function () {
            if (deferredPrompt) {
                deferredPrompt.prompt();
                deferredPrompt.userChoice.then(function (choice) {
                    if (choice.outcome === 'accepted') hideInstallBanner();
                    deferredPrompt = null;
                });
            }
        });
        document.getElementById('lms-pwa-dismiss-btn').addEventListener('click', function () {
            try { localStorage.setItem('lms-pwa-install-dismissed', '1'); } catch (x) {}
            hideInstallBanner();
        });
    }

    function showUpdateBanner() {
        hideInstallBanner();
        var existing = document.getElementById('lms-pwa-update-banner');
        if (existing) return;
        var banner = document.createElement('div');
        banner.id = 'lms-pwa-update-banner';
        banner.setAttribute('role', 'alert');
        banner.className = 'lms-pwa-banner lms-pwa-banner-update';
        banner.style.cssText = 'position:fixed;bottom:0;left:0;right:0;background:#059669;color:#fff;padding:12px 16px;text-align:center;z-index:9999;font-family:\'Cairo\',sans-serif;direction:rtl;';
        banner.innerHTML = '<span>يتوفر تحديث جديد. تحديث الآن سيُعيد تحميل الصفحة.</span> <button type="button" id="lms-pwa-reload-btn" style="background:rgba(255,255,255,.25);color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-family:inherit;margin-right:8px;">تحديث الآن</button>';
        document.body.appendChild(banner);
        document.getElementById('lms-pwa-reload-btn').addEventListener('click', function () {
            navigator.serviceWorker.getRegistration().then(function (r) { if (r && r.waiting) r.waiting.postMessage({ type: 'SKIP_WAITING' }); });
        });
    }

    function hideInstallBanner() {
        var el = document.getElementById('lms-pwa-install-banner');
        if (el) el.remove();
    }

    if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.addEventListener('controllerchange', function () {
            window.location.reload();
        });
    }

    /* ----- Offline bar and form submit guard ----- */
    function showOfflineBar() {
        if (document.getElementById('lms-pwa-offline-bar')) return;
        var bar = document.createElement('div');
        bar.id = 'lms-pwa-offline-bar';
        bar.setAttribute('role', 'alert');
        bar.className = 'lms-pwa-offline-bar';
        bar.style.cssText = 'position:fixed;top:0;left:0;right:0;background:#b91c1c;color:#fff;padding:10px 16px;text-align:center;z-index:10000;font-family:\'Cairo\',sans-serif;direction:rtl;font-weight:600;display:flex;align-items:center;justify-content:center;gap:12px;flex-wrap:wrap;';
        bar.innerHTML = '<span>أنت غير متصل. تحقق من الشبكة.</span><button type="button" id="lms-pwa-offline-retry" style="background:rgba(255,255,255,.25);color:#fff;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-family:inherit;">إعادة المحاولة</button>';
        document.body.appendChild(bar);
        document.getElementById('lms-pwa-offline-retry').addEventListener('click', function () {
            if (navigator.onLine) window.location.reload();
        });
    }

    function hideOfflineBar() {
        var el = document.getElementById('lms-pwa-offline-bar');
        if (el) el.remove();
    }

    function updateOfflineUI() {
        if (!navigator.onLine) showOfflineBar();
        else hideOfflineBar();
    }

    window.addEventListener('online', updateOfflineUI);
    window.addEventListener('offline', updateOfflineUI);
    if (!navigator.onLine) showOfflineBar();

    document.addEventListener('submit', function (e) {
        var form = e.target && e.target.tagName === 'FORM' ? e.target : null;
        if (!form) return;
        if (form.getAttribute('data-pwa-allow-offline') === 'true') return;
        if (navigator.onLine) return;
        e.preventDefault();
        showOfflineBar();
        return false;
    }, true);
})();
