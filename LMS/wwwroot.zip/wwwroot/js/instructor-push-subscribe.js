/**
 * Instructor Web Push - request permission, subscribe, and POST to backend
 * Loaded only in Instructor area. RTL/Arabic UX.
 */
(function () {
    'use strict';

    if (!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) return;

    var STORAGE_KEY = 'lms-pwa-push-subscribed';
    var BASE = window.location.origin + '/Instructor';

    function urlBase64ToUint8Array(base64String) {
        var padding = '='.repeat((4 - base64String.length % 4) % 4);
        var base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
        var raw = window.atob(base64);
        var out = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
        return out;
    }

    function trySubscribe() {
        return navigator.serviceWorker.ready.then(function (reg) {
            return fetch(BASE + '/Notifications/PushPublicKey', { credentials: 'same-origin' })
                .then(function (res) {
                    if (!res.ok) return null;
                    return res.json();
                })
                .then(function (data) {
                    if (!data || !data.publicKey) return null;
                    var key = urlBase64ToUint8Array(data.publicKey);
                    return reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key });
                })
                .then(function (subscription) {
                    if (!subscription) return null;
                    var keyP256 = subscription.getKey('p256dh');
                    var keyAuth = subscription.getKey('auth');
                    var p256dh = keyP256 ? btoa(String.fromCharCode.apply(null, new Uint8Array(keyP256))) : '';
                    var auth = keyAuth ? btoa(String.fromCharCode.apply(null, new Uint8Array(keyAuth))) : '';
                    if (!p256dh || !auth) return null;
                    return fetch(BASE + '/Notifications/SubscribePush', {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            endpoint: subscription.endpoint,
                            keys: { p256dh: p256dh, auth: auth },
                            userAgent: navigator.userAgent.substring(0, 500),
                            deviceLabel: null
                        })
                    });
                })
                .then(function (res) {
                    if (res && res.status === 200) {
                        try { localStorage.setItem(STORAGE_KEY, '1'); } catch (e) {}
                        return true;
                    }
                    if (res && (res.status === 401 || res.status === 403)) return false;
                    return null;
                });
        });
    }

    function run() {
        try { if (localStorage.getItem(STORAGE_KEY) === '1') return; } catch (e) {}
        if (Notification.permission === 'granted') {
            trySubscribe().then(function (ok) {
                if (ok === false) return;
            });
            return;
        }
        if (Notification.permission === 'denied') return;
        if (Notification.permission === 'default') {
            var btn = document.getElementById('lms-instructor-enable-push');
            if (btn) {
                btn.addEventListener('click', function () {
                    btn.disabled = true;
                    Notification.requestPermission().then(function (perm) {
                        if (perm === 'granted') {
                            trySubscribe().then(function (ok) {
                                if (ok === true) btn.textContent = 'تم تفعيل إشعارات الجوال';
                                else if (ok === false) btn.textContent = 'يجب تسجيل الدخول';
                            });
                        } else {
                            btn.disabled = false;
                        }
                    });
                });
            } else {
                setTimeout(function () {
                    if (Notification.permission !== 'default') return;
                    try { if (localStorage.getItem(STORAGE_KEY) === '1') return; } catch (e) {}
                    Notification.requestPermission().then(function (perm) {
                        if (perm === 'granted') trySubscribe();
                    });
                }, 3000);
            }
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', run);
    } else {
        run();
    }
})();
