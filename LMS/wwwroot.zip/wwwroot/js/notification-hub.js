/**
 * خدمة الإشعارات في الوقت الفعلي - Real-time Notification Hub Client
 * Handles SignalR connection and notification display
 */

// Global notification hub instance
let notificationHub = null;

/**
 * Initialize the notification hub connection
 */
function initNotificationHub() {
    if (!currentUserId) {
        console.log('No user ID available, skipping notification hub initialization');
        return;
    }

    notificationHub = new signalR.HubConnectionBuilder()
        .withUrl("/hubs/notifications")
        .withAutomaticReconnect([0, 2000, 5000, 10000, 30000])
        .configureLogging(signalR.LogLevel.Warning)
        .build();

    // Handle new notification
    notificationHub.on("ReceiveNotification", function (notification) {
        console.log("New notification received:", notification);
        showNotificationToast(notification);
        addNotificationToDropdown(notification);
        updateUnreadBadge(notification);
    });

    // Handle unread count update
    notificationHub.on("UpdateUnreadCount", function (count) {
        updateUnreadCount(count);
    });

    // Handle notification read
    notificationHub.on("NotificationRead", function (notificationId) {
        markNotificationAsReadInUI(notificationId);
    });

    // Handle refresh request
    notificationHub.on("RefreshNotifications", function () {
        refreshNotificationsList();
    });

    // Connection state change handlers
    notificationHub.onreconnecting(function (error) {
        console.log('Notification hub reconnecting...', error);
        updateConnectionStatus('reconnecting');
    });

    notificationHub.onreconnected(function (connectionId) {
        console.log('Notification hub reconnected:', connectionId);
        updateConnectionStatus('connected');
        refreshNotificationCount();
    });

    notificationHub.onclose(function (error) {
        console.log('Notification hub connection closed:', error);
        updateConnectionStatus('disconnected');
        // Try to reconnect after 5 seconds
        setTimeout(function () {
            startNotificationHub();
        }, 5000);
    });

    // Start the connection
    startNotificationHub();
}

/**
 * Start the SignalR connection
 */
function startNotificationHub() {
    if (!notificationHub) {
        initNotificationHub();
        return;
    }

    notificationHub.start()
        .then(function () {
            console.log('Notification hub connected');
            updateConnectionStatus('connected');
        })
        .catch(function (err) {
            console.error('Notification hub connection error:', err);
            updateConnectionStatus('error');
            // Retry after 5 seconds
            setTimeout(startNotificationHub, 5000);
        });
}

/**
 * Show notification toast
 */
function showNotificationToast(notification) {
    var toastContainer = document.getElementById('notification-toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'notification-toast-container';
        toastContainer.className = 'position-fixed';
        toastContainer.style.cssText = 'top: 80px; left: 20px; z-index: 9999;';
        document.body.appendChild(toastContainer);
    }

    var toastId = 'toast-' + Date.now();
    var toastHtml = `
        <div class="toast show" id="${toastId}" role="alert" aria-live="assertive" aria-atomic="true" 
             style="min-width: 350px; animation: slideInRight 0.3s ease;">
            <div class="toast-header bg-${notification.color || 'primary'} text-white">
                <i class="${notification.icon || 'feather-bell'} me-2"></i>
                <strong class="me-auto">${notification.title}</strong>
                <small class="text-white-50">${notification.timeAgo || 'الآن'}</small>
                <button type="button" class="btn-close btn-close-white" onclick="closeToast('${toastId}')" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                <p class="mb-2">${notification.message}</p>
                ${notification.actionUrl ? `
                    <div class="d-flex gap-2">
                        <a href="${notification.actionUrl}" class="btn btn-sm btn-${notification.color || 'primary'}">
                            <i class="feather-external-link me-1"></i>
                            ${notification.actionText || 'عرض'}
                        </a>
                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="closeToast('${toastId}')">
                            إغلاق
                        </button>
                    </div>
                ` : ''}
            </div>
        </div>
    `;

    toastContainer.insertAdjacentHTML('beforeend', toastHtml);

    // Play notification sound if enabled
    playNotificationSound();

    // Auto-hide after 8 seconds
    setTimeout(function () {
        closeToast(toastId);
    }, 8000);
}

/**
 * Close a toast notification
 */
function closeToast(toastId) {
    var toast = document.getElementById(toastId);
    if (toast) {
        toast.style.animation = 'slideOutRight 0.3s ease';
        setTimeout(function () {
            toast.remove();
        }, 300);
    }
}

/**
 * Add notification to dropdown
 */
function addNotificationToDropdown(notification) {
    var notificationsList = document.getElementById('notifications-list');
    var noNotificationsMessage = document.getElementById('no-notifications-message');

    if (!notificationsList) return;

    // Remove "no notifications" message if present
    if (noNotificationsMessage) {
        noNotificationsMessage.remove();
    }

    var notificationHtml = `
        <div class="notifications-item" data-notification-id="${notification.id}">
            <div class="avatar-text avatar-sm bg-soft-${notification.color || 'primary'} text-${notification.color || 'primary'}">
                <i class="${notification.icon || 'feather-bell'}"></i>
            </div>
            <div class="notifications-desc">
                <a href="${notification.actionUrl || '/Instructor/Notifications'}" class="font-body text-truncate-2-line">
                    <span class="fw-semibold text-dark">${notification.title}</span>
                    <span class="text-muted">${notification.message}</span>
                </a>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="notifications-date text-muted border-bottom border-bottom-dashed">
                        ${notification.timeAgo || 'الآن'}
                    </div>
                    ${notification.priority >= 4 ? `
                        <span class="badge bg-${getPriorityColor(notification.priority)}" style="font-size: 9px;">
                            ${getPriorityLabel(notification.priority)}
                        </span>
                    ` : ''}
                </div>
            </div>
        </div>
    `;

    // Add to the top of the list
    notificationsList.insertAdjacentHTML('afterbegin', notificationHtml);

    // Limit to 5 notifications in dropdown
    var items = notificationsList.querySelectorAll('.notifications-item');
    if (items.length > 5) {
        items[items.length - 1].remove();
    }
}

/**
 * Update unread badge
 */
function updateUnreadBadge(notification) {
    var badge = document.getElementById('unread-notifications-badge');
    var dropdownCount = document.getElementById('dropdown-unread-count');

    if (badge) {
        var currentCount = parseInt(badge.textContent) || 0;
        var newCount = currentCount + 1;
        badge.textContent = newCount > 99 ? '99+' : newCount;
        badge.style.display = 'inline-block';
    }

    if (dropdownCount) {
        var currentDropdownCount = parseInt(dropdownCount.textContent) || 0;
        var newDropdownCount = currentDropdownCount + 1;
        dropdownCount.textContent = newDropdownCount;
        dropdownCount.style.display = 'inline-block';
    }
}

/**
 * Update unread count directly
 */
function updateUnreadCount(count) {
    var badge = document.getElementById('unread-notifications-badge');
    var dropdownCount = document.getElementById('dropdown-unread-count');

    if (badge) {
        if (count > 0) {
            badge.textContent = count > 99 ? '99+' : count;
            badge.style.display = 'inline-block';
        } else {
            badge.style.display = 'none';
        }
    }

    if (dropdownCount) {
        if (count > 0) {
            dropdownCount.textContent = count;
            dropdownCount.style.display = 'inline-block';
        } else {
            dropdownCount.style.display = 'none';
        }
    }
}

/**
 * Mark notification as read in UI
 */
function markNotificationAsReadInUI(notificationId) {
    var notificationElement = document.querySelector(`[data-notification-id="${notificationId}"]`);
    if (notificationElement) {
        notificationElement.classList.remove('bg-soft-primary');
        notificationElement.classList.add('bg-light');

        // Remove "new" badge if present
        var newBadge = notificationElement.querySelector('.badge.bg-danger');
        if (newBadge && newBadge.textContent.includes('جديد')) {
            newBadge.remove();
        }
    }
}

/**
 * Refresh notifications list
 */
function refreshNotificationsList() {
    if (window.location.pathname.includes('/Notifications')) {
        window.location.reload();
    } else {
        refreshNotificationCount();
    }
}

/**
 * Refresh notification count from server
 */
function refreshNotificationCount() {
    fetch('/Instructor/Notifications/GetUnreadCount')
        .then(response => response.json())
        .then(data => {
            updateUnreadCount(data.count);
        })
        .catch(error => {
            console.error('Error refreshing notification count:', error);
        });
}

/**
 * Update connection status indicator (if present)
 */
function updateConnectionStatus(status) {
    var statusIndicator = document.getElementById('notification-connection-status');
    if (!statusIndicator) return;

    switch (status) {
        case 'connected':
            statusIndicator.className = 'badge bg-success';
            statusIndicator.textContent = 'متصل';
            break;
        case 'reconnecting':
            statusIndicator.className = 'badge bg-warning';
            statusIndicator.textContent = 'جاري الاتصال...';
            break;
        case 'disconnected':
        case 'error':
            statusIndicator.className = 'badge bg-danger';
            statusIndicator.textContent = 'غير متصل';
            break;
    }
}

/**
 * Play notification sound
 */
function playNotificationSound() {
    // Check if sound is enabled in preferences
    var soundEnabled = localStorage.getItem('notificationSoundEnabled');
    if (soundEnabled === 'false') return;

    try {
        var audio = new Audio('/assets/sounds/notification.mp3');
        audio.volume = 0.3;
        audio.play().catch(function () {
            // Autoplay was prevented, ignore
        });
    } catch (e) {
        // Audio not supported or file not found
    }
}

/**
 * Get priority color
 */
function getPriorityColor(priority) {
    switch (priority) {
        case 5: return 'danger';
        case 4: return 'warning';
        case 3: return 'primary';
        case 2: return 'info';
        default: return 'secondary';
    }
}

/**
 * Get priority label
 */
function getPriorityLabel(priority) {
    switch (priority) {
        case 5: return 'عاجل';
        case 4: return 'مهم';
        case 3: return 'عادي';
        case 2: return 'منخفض';
        default: return 'أرشيف';
    }
}

// CSS Animation styles (inject if not present)
(function () {
    var style = document.createElement('style');
    style.textContent = `
        @keyframes slideInRight {
            from {
                transform: translateX(-100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(-100%);
                opacity: 0;
            }
        }
        
        .toast {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border-radius: 8px;
            margin-bottom: 10px;
        }
        
        .notification-pulse {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0%, 100% {
                transform: scale(1);
            }
            50% {
                transform: scale(1.1);
            }
        }
    `;
    document.head.appendChild(style);
})();

// Initialize on DOM ready
document.addEventListener('DOMContentLoaded', function () {
    // Check if user is logged in (currentUserId should be set in the page)
    if (typeof currentUserId !== 'undefined' && currentUserId) {
        initNotificationHub();

        // Fallback: Poll for notifications every 30 seconds
        setInterval(refreshNotificationCount, 30000);
    }
});


