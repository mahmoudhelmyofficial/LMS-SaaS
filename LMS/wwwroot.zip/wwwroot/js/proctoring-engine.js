/**
 * Enterprise Proctoring Engine
 * Client-side exam monitoring and violation detection
 * 
 * Usage:
 *   const proctoring = new ProctoringEngine({
 *       preventTabSwitch: true,
 *       preventCopyPaste: true,
 *       disableRightClick: true,
 *       requireFullscreen: false,
 *       requireWebcam: false,
 *       captureScreenshots: false,
 *       screenshotInterval: 30,
 *       maxWarnings: 3,
 *       autoTerminate: true,
 *       onViolation: (violation) => {},
 *       onTerminate: () => {},
 *       antiForgeryToken: ''
 *   });
 *   await proctoring.initialize(sessionId);
 */
class ProctoringEngine {
    constructor(config = {}) {
        this.config = {
            preventTabSwitch: config.preventTabSwitch ?? true,
            preventCopyPaste: config.preventCopyPaste ?? true,
            disableRightClick: config.disableRightClick ?? true,
            requireFullscreen: config.requireFullscreen ?? false,
            requireWebcam: config.requireWebcam ?? false,
            captureScreenshots: config.captureScreenshots ?? false,
            screenshotInterval: config.screenshotInterval ?? 30,
            maxWarnings: config.maxWarnings ?? 3,
            autoTerminate: config.autoTerminate ?? true,
            onViolation: config.onViolation ?? null,
            onTerminate: config.onTerminate ?? null,
            antiForgeryToken: config.antiForgeryToken ?? ''
        };

        this.sessionId = null;
        this.violations = [];
        this.warningCount = 0;
        this.isActive = false;
        this.webcamStream = null;
        this.screenshotInterval = null;
        this.faceCheckInterval = null;
        this.tabSwitchCount = 0;

        // Bound event handlers for proper cleanup
        this._boundHandlers = {
            visibilityChange: this._onVisibilityChange.bind(this),
            windowBlur: this._onWindowBlur.bind(this),
            windowFocus: this._onWindowFocus.bind(this),
            copy: this._onCopy.bind(this),
            cut: this._onCut.bind(this),
            paste: this._onPaste.bind(this),
            contextMenu: this._onContextMenu.bind(this),
            keyDown: this._onKeyDown.bind(this),
            fullscreenChange: this._onFullscreenChange.bind(this),
            resize: this._onResize.bind(this),
            beforeUnload: this._onBeforeUnload.bind(this)
        };

        this._lastWindowSize = { width: window.outerWidth, height: window.outerHeight };
        this._devToolsCheckInterval = null;
        this._blurTimestamp = null;
    }

    /**
     * Get the anti-forgery token from the page
     * @returns {string} The anti-forgery token value or empty string
     */
    getAntiForgeryToken() {
        return document.querySelector('[name="__RequestVerificationToken"]')?.value || '';
    }

    /**
     * Initialize the proctoring engine for a quiz session
     * @param {string|number} sessionId - The quiz session identifier
     */
    async initialize(sessionId) {
        if (!sessionId) {
            console.error('ProctoringEngine: sessionId is required');
            return false;
        }

        this.sessionId = sessionId;
        this.isActive = true;
        this.violations = [];
        this.warningCount = 0;
        this.tabSwitchCount = 0;

        try {
            if (this.config.requireWebcam) {
                await this.initWebcam();
            }

            this.startMonitoring();
            console.log('ProctoringEngine: Initialized successfully for session', sessionId);
            return true;
        } catch (error) {
            console.error('ProctoringEngine: Initialization failed', error);
            await this.reportViolation('initialization_error', error.message, 'low');
            return false;
        }
    }

    /**
     * Start all monitoring activities based on config
     */
    startMonitoring() {
        if (!this.isActive) return;

        if (this.config.preventTabSwitch) {
            this.monitorTabVisibility();
        }

        if (this.config.preventCopyPaste) {
            this.preventCopyPaste();
        }

        if (this.config.disableRightClick) {
            this.disableRightClick();
        }

        if (this.config.requireFullscreen) {
            this.enforceFullscreen();
        }

        if (this.config.captureScreenshots && this.config.requireWebcam) {
            this.startScreenshotCapture();
        }

        this.detectDevTools();
        this.monitorBrowserResize();
        this.preventNavigation();
    }

    // ========== TAB VISIBILITY MONITORING ==========

    /**
     * Monitor tab visibility changes and window blur/focus events
     */
    monitorTabVisibility() {
        document.addEventListener('visibilitychange', this._boundHandlers.visibilityChange);
        window.addEventListener('blur', this._boundHandlers.windowBlur);
        window.addEventListener('focus', this._boundHandlers.windowFocus);
    }

    /** @private */
    _onVisibilityChange() {
        if (!this.isActive) return;

        if (document.hidden) {
            this.tabSwitchCount++;
            const violation = {
                type: 'tab_switch',
                description: `تم تبديل التبويب (المرة ${this.tabSwitchCount})`,
                severity: this.tabSwitchCount >= 3 ? 'high' : 'medium',
                timestamp: new Date().toISOString()
            };

            this.violations.push(violation);
            this.warningCount++;
            this.reportViolation(violation.type, violation.description, violation.severity);
            this.showWarning(`تحذير: تم اكتشاف تبديل تبويب (${this.tabSwitchCount})`);

            if (this.warningCount >= this.config.maxWarnings) {
                this.handleMaxWarnings();
            }
        }
    }

    /** @private */
    _onWindowBlur() {
        if (!this.isActive) return;
        this._blurTimestamp = Date.now();
    }

    /** @private */
    _onWindowFocus() {
        if (!this.isActive || !this._blurTimestamp) return;

        const awayDuration = Date.now() - this._blurTimestamp;
        this._blurTimestamp = null;

        // If away for more than 3 seconds, log it
        if (awayDuration > 3000) {
            const seconds = Math.round(awayDuration / 1000);
            this.reportViolation(
                'window_unfocused',
                `النافذة فقدت التركيز لمدة ${seconds} ثانية`,
                awayDuration > 10000 ? 'high' : 'low'
            );
        }
    }

    // ========== COPY/PASTE PREVENTION ==========

    /**
     * Prevent copy, cut, and paste operations
     */
    preventCopyPaste() {
        document.addEventListener('copy', this._boundHandlers.copy);
        document.addEventListener('cut', this._boundHandlers.cut);
        document.addEventListener('paste', this._boundHandlers.paste);
        document.addEventListener('keydown', this._boundHandlers.keyDown);
    }

    /** @private */
    _onCopy(e) {
        if (!this.isActive) return;
        e.preventDefault();
        this.reportViolation('copy_attempt', 'محاولة نسخ محتوى', 'medium');
        this.showWarning('تحذير: النسخ غير مسموح أثناء الاختبار');
        this.warningCount++;
        if (this.warningCount >= this.config.maxWarnings) this.handleMaxWarnings();
    }

    /** @private */
    _onCut(e) {
        if (!this.isActive) return;
        e.preventDefault();
        this.reportViolation('cut_attempt', 'محاولة قص محتوى', 'medium');
        this.showWarning('تحذير: القص غير مسموح أثناء الاختبار');
        this.warningCount++;
        if (this.warningCount >= this.config.maxWarnings) this.handleMaxWarnings();
    }

    /** @private */
    _onPaste(e) {
        if (!this.isActive) return;
        e.preventDefault();
        this.reportViolation('paste_attempt', 'محاولة لصق محتوى', 'medium');
        this.showWarning('تحذير: اللصق غير مسموح أثناء الاختبار');
        this.warningCount++;
        if (this.warningCount >= this.config.maxWarnings) this.handleMaxWarnings();
    }

    /** @private */
    _onKeyDown(e) {
        if (!this.isActive) return;

        // Block Ctrl+C, Ctrl+V, Ctrl+X, Ctrl+A, Ctrl+P, F12
        if (e.ctrlKey || e.metaKey) {
            const blockedKeys = ['c', 'v', 'x', 'a', 'p', 'u', 's'];
            if (blockedKeys.includes(e.key.toLowerCase())) {
                e.preventDefault();
                return false;
            }
        }

        // Block F12 (DevTools)
        if (e.key === 'F12') {
            e.preventDefault();
            this.reportViolation('devtools_shortcut', 'محاولة فتح أدوات المطور', 'high');
            this.showWarning('تحذير: أدوات المطور غير مسموحة');
            this.warningCount++;
            if (this.warningCount >= this.config.maxWarnings) this.handleMaxWarnings();
            return false;
        }

        // Block Ctrl+Shift+I (DevTools)
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'i') {
            e.preventDefault();
            this.reportViolation('devtools_shortcut', 'محاولة فتح أدوات المطور', 'high');
            this.warningCount++;
            if (this.warningCount >= this.config.maxWarnings) this.handleMaxWarnings();
            return false;
        }

        // Block Ctrl+Shift+J (Console)
        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'j') {
            e.preventDefault();
            return false;
        }
    }

    // ========== RIGHT-CLICK DISABLE ==========

    /**
     * Disable right-click context menu
     */
    disableRightClick() {
        document.addEventListener('contextmenu', this._boundHandlers.contextMenu);
    }

    /** @private */
    _onContextMenu(e) {
        if (!this.isActive) return;
        e.preventDefault();
        this.reportViolation('right_click', 'محاولة استخدام القائمة السياقية', 'low');
        return false;
    }

    // ========== FULLSCREEN ENFORCEMENT ==========

    /**
     * Enforce fullscreen mode using the Fullscreen API
     */
    enforceFullscreen() {
        document.addEventListener('fullscreenchange', this._boundHandlers.fullscreenChange);
        document.addEventListener('webkitfullscreenchange', this._boundHandlers.fullscreenChange);
        document.addEventListener('mozfullscreenchange', this._boundHandlers.fullscreenChange);
        document.addEventListener('MSFullscreenChange', this._boundHandlers.fullscreenChange);

        // Request fullscreen
        this._requestFullscreen();
    }

    /** @private */
    _requestFullscreen() {
        const docEl = document.documentElement;
        const requestFn = docEl.requestFullscreen ||
                          docEl.webkitRequestFullscreen ||
                          docEl.mozRequestFullScreen ||
                          docEl.msRequestFullscreen;

        if (requestFn) {
            requestFn.call(docEl).catch(err => {
                console.warn('ProctoringEngine: Could not enter fullscreen', err);
                this.showWarning('يرجى تفعيل وضع ملء الشاشة للاستمرار في الاختبار');
            });
        }
    }

    /** @private */
    _onFullscreenChange() {
        if (!this.isActive) return;

        const isFullscreen = !!(document.fullscreenElement ||
                                document.webkitFullscreenElement ||
                                document.mozFullScreenElement ||
                                document.msFullscreenElement);

        if (!isFullscreen) {
            this.reportViolation('fullscreen_exit', 'تم الخروج من وضع ملء الشاشة', 'high');
            this.warningCount++;
            this.showWarning('تحذير: يجب البقاء في وضع ملء الشاشة');

            // Re-request fullscreen after a short delay
            setTimeout(() => {
                if (this.isActive) {
                    this._requestFullscreen();
                }
            }, 1000);

            if (this.warningCount >= this.config.maxWarnings) {
                this.handleMaxWarnings();
            }
        }
    }

    // ========== WEBCAM INITIALIZATION ==========

    /**
     * Initialize webcam stream for face monitoring
     */
    async initWebcam() {
        try {
            this.webcamStream = await navigator.mediaDevices.getUserMedia({
                video: {
                    width: { ideal: 640 },
                    height: { ideal: 480 },
                    facingMode: 'user'
                }
            });

            // Create a small preview element if needed
            let preview = document.getElementById('proctoring-webcam-preview');
            if (!preview) {
                preview = document.createElement('video');
                preview.id = 'proctoring-webcam-preview';
                preview.autoplay = true;
                preview.muted = true;
                preview.playsInline = true;
                preview.style.cssText = 'position: fixed; bottom: 16px; left: 16px; width: 120px; height: 90px; border-radius: 8px; border: 2px solid #28a745; z-index: 9999; object-fit: cover; box-shadow: 0 4px 12px rgba(0,0,0,0.3);';
                document.body.appendChild(preview);
            }

            preview.srcObject = this.webcamStream;
            console.log('ProctoringEngine: Webcam initialized');
            return true;
        } catch (error) {
            console.error('ProctoringEngine: Webcam access denied', error);
            await this.reportViolation(
                'webcam_denied',
                'تم رفض الوصول إلى الكاميرا',
                'high'
            );
            this.showWarning('تحذير: يجب السماح بالوصول إلى الكاميرا لاستمرار الاختبار');
            return false;
        }
    }

    // ========== SCREENSHOT CAPTURE ==========

    /**
     * Start periodic screenshot capture from webcam
     */
    startScreenshotCapture() {
        if (!this.webcamStream) return;

        const intervalMs = (this.config.screenshotInterval || 30) * 1000;

        this.screenshotInterval = setInterval(async () => {
            if (!this.isActive || !this.webcamStream) return;

            try {
                const canvas = document.createElement('canvas');
                const video = document.getElementById('proctoring-webcam-preview');

                if (!video || !video.videoWidth) return;

                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;

                const ctx = canvas.getContext('2d');
                ctx.drawImage(video, 0, 0);

                const imageDataUrl = canvas.toDataURL('image/jpeg', 0.6);

                // Send screenshot to server
                await this._sendScreenshot(imageDataUrl);
            } catch (error) {
                console.error('ProctoringEngine: Screenshot capture failed', error);
            }
        }, intervalMs);
    }

    /** @private */
    async _sendScreenshot(imageDataUrl) {
        try {
            const token = this.config.antiForgeryToken || this.getAntiForgeryToken();

            await fetch('/Student/Quizzes/UploadProctoringScreenshot', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'RequestVerificationToken': token
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    imageData: imageDataUrl,
                    timestamp: new Date().toISOString()
                })
            });
        } catch (error) {
            console.error('ProctoringEngine: Failed to upload screenshot', error);
        }
    }

    // ========== DEVTOOLS DETECTION ==========

    /**
     * Detect if browser developer tools are open
     */
    detectDevTools() {
        // Method: Check outer vs inner window size difference
        this._devToolsCheckInterval = setInterval(() => {
            if (!this.isActive) return;

            const widthDiff = window.outerWidth - window.innerWidth;
            const heightDiff = window.outerHeight - window.innerHeight;
            const threshold = 160; // DevTools typically adds >160px

            if (widthDiff > threshold || heightDiff > threshold) {
                this.reportViolation(
                    'devtools_open',
                    'يبدو أن أدوات المطور مفتوحة',
                    'high'
                );
                this.showWarning('تحذير: تم اكتشاف أدوات المطور. يرجى إغلاقها فوراً');
                this.warningCount++;

                if (this.warningCount >= this.config.maxWarnings) {
                    this.handleMaxWarnings();
                }
            }
        }, 2000);
    }

    // ========== BROWSER RESIZE MONITORING ==========

    /**
     * Monitor browser resize events for suspicious resizing
     */
    monitorBrowserResize() {
        window.addEventListener('resize', this._boundHandlers.resize);
    }

    /** @private */
    _onResize() {
        if (!this.isActive) return;

        const currentWidth = window.outerWidth;
        const currentHeight = window.outerHeight;
        const widthChange = Math.abs(currentWidth - this._lastWindowSize.width);
        const heightChange = Math.abs(currentHeight - this._lastWindowSize.height);

        // Only flag significant resizes (more than 200px change)
        if (widthChange > 200 || heightChange > 200) {
            this.reportViolation(
                'window_resize',
                `تم تغيير حجم النافذة بشكل كبير (${widthChange}x${heightChange})`,
                'low'
            );
        }

        this._lastWindowSize = { width: currentWidth, height: currentHeight };
    }

    // ========== NAVIGATION PREVENTION ==========

    /**
     * Prevent navigation away from the quiz page
     */
    preventNavigation() {
        window.addEventListener('beforeunload', this._boundHandlers.beforeUnload);
    }

    /** @private */
    _onBeforeUnload(e) {
        if (!this.isActive) return;
        e.preventDefault();
        e.returnValue = 'هل أنت متأكد من مغادرة الاختبار؟ سيتم إنهاء محاولتك.';
        return e.returnValue;
    }

    // ========== VIOLATION REPORTING ==========

    /**
     * Report a violation to the server
     * @param {string} type - Violation type identifier
     * @param {string} description - Human-readable description
     * @param {string} severity - 'low', 'medium', or 'high'
     */
    async reportViolation(type, description, severity = 'medium') {
        const violation = {
            sessionId: this.sessionId,
            violationType: type,
            severity: severity,
            description: description,
            screenshotUrl: null,
            timestamp: new Date().toISOString()
        };

        this.violations.push(violation);

        // Notify callback
        if (typeof this.config.onViolation === 'function') {
            this.config.onViolation(violation);
        }

        // Send to server
        try {
            const token = this.config.antiForgeryToken || this.getAntiForgeryToken();

            const response = await fetch('/Student/Quizzes/ReportViolation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': token,
                    'RequestVerificationToken': token
                },
                body: JSON.stringify(violation)
            });

            if (!response.ok) {
                console.error('ProctoringEngine: Failed to report violation', response.status);
            }
        } catch (error) {
            console.error('ProctoringEngine: Error reporting violation', error);
        }
    }

    // ========== WARNING TOAST ==========

    /**
     * Show a warning toast notification to the user
     * @param {string} message - Warning message in Arabic
     */
    showWarning(message) {
        // Try to use existing toast infrastructure first
        const existingToast = document.getElementById('proctoringToast');
        if (existingToast) {
            const body = existingToast.querySelector('.toast-body');
            if (body) body.textContent = message;
            const toast = new bootstrap.Toast(existingToast, { delay: 4000 });
            toast.show();
            return;
        }

        // Create toast container if it doesn't exist
        let container = document.getElementById('proctoring-toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'proctoring-toast-container';
            container.className = 'position-fixed top-0 start-50 translate-middle-x p-3';
            container.style.zIndex = '9999';
            document.body.appendChild(container);
        }

        // Create toast element
        const toastId = 'proctoring-toast-' + Date.now();
        const toastHtml = `
            <div id="${toastId}" class="toast align-items-center text-bg-warning border-0" role="alert" aria-live="assertive">
                <div class="d-flex">
                    <div class="toast-body d-flex align-items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/>
                            <line x1="12" y1="9" x2="12" y2="13"/>
                            <line x1="12" y1="17" x2="12.01" y2="17"/>
                        </svg>
                        <span>${message}</span>
                        <span class="badge bg-dark rounded-pill ms-2">${this.warningCount}/${this.config.maxWarnings}</span>
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="إغلاق"></button>
                </div>
            </div>
        `;

        container.insertAdjacentHTML('beforeend', toastHtml);

        const toastEl = document.getElementById(toastId);
        if (toastEl && typeof bootstrap !== 'undefined') {
            const toast = new bootstrap.Toast(toastEl, { delay: 4000 });
            toast.show();

            // Remove from DOM after hidden
            toastEl.addEventListener('hidden.bs.toast', () => {
                toastEl.remove();
            });
        }
    }

    // ========== MAX WARNINGS HANDLER ==========

    /**
     * Handle when maximum warning count is exceeded
     */
    handleMaxWarnings() {
        this.reportViolation(
            'max_warnings_exceeded',
            `تجاوز الحد الأقصى للتحذيرات (${this.config.maxWarnings})`,
            'critical'
        );

        if (this.config.autoTerminate) {
            this.showWarning('تم إنهاء الاختبار تلقائياً بسبب تجاوز الحد الأقصى للمخالفات');

            // Notify callback
            if (typeof this.config.onTerminate === 'function') {
                this.config.onTerminate();
            }

            // Auto-submit quiz after a short delay
            setTimeout(() => {
                this._autoSubmitQuiz();
            }, 2000);
        } else {
            this.showWarning(`تحذير أخير: لقد تجاوزت ${this.config.maxWarnings} مخالفات. سيتم تسجيل جميع المخالفات.`);
        }
    }

    /** @private */
    async _autoSubmitQuiz() {
        try {
            // Look for the quiz submit form/button
            const submitBtn = document.querySelector('[data-proctoring-submit]') ||
                              document.querySelector('#submitQuizBtn') ||
                              document.querySelector('form[data-quiz-form] button[type="submit"]');

            if (submitBtn) {
                submitBtn.click();
            } else {
                // Fallback: submit via AJAX
                const token = this.config.antiForgeryToken || this.getAntiForgeryToken();

                await fetch('/Student/Quizzes/AutoSubmit', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': token,
                        'RequestVerificationToken': token
                    },
                    body: JSON.stringify({
                        sessionId: this.sessionId,
                        reason: 'max_warnings_exceeded'
                    })
                });

                // Redirect to results page
                window.location.href = `/Student/Quizzes/Result/${this.sessionId}`;
            }
        } catch (error) {
            console.error('ProctoringEngine: Auto-submit failed', error);
        }
    }

    // ========== CLEANUP ==========

    /**
     * Destroy the proctoring engine and clean up all resources
     */
    destroy() {
        this.isActive = false;

        // Remove visibility/focus listeners
        document.removeEventListener('visibilitychange', this._boundHandlers.visibilityChange);
        window.removeEventListener('blur', this._boundHandlers.windowBlur);
        window.removeEventListener('focus', this._boundHandlers.windowFocus);

        // Remove copy/paste listeners
        document.removeEventListener('copy', this._boundHandlers.copy);
        document.removeEventListener('cut', this._boundHandlers.cut);
        document.removeEventListener('paste', this._boundHandlers.paste);
        document.removeEventListener('keydown', this._boundHandlers.keyDown);

        // Remove right-click listener
        document.removeEventListener('contextmenu', this._boundHandlers.contextMenu);

        // Remove fullscreen listeners
        document.removeEventListener('fullscreenchange', this._boundHandlers.fullscreenChange);
        document.removeEventListener('webkitfullscreenchange', this._boundHandlers.fullscreenChange);
        document.removeEventListener('mozfullscreenchange', this._boundHandlers.fullscreenChange);
        document.removeEventListener('MSFullscreenChange', this._boundHandlers.fullscreenChange);

        // Remove resize listener
        window.removeEventListener('resize', this._boundHandlers.resize);

        // Remove beforeunload listener
        window.removeEventListener('beforeunload', this._boundHandlers.beforeUnload);

        // Clear intervals
        if (this.screenshotInterval) {
            clearInterval(this.screenshotInterval);
            this.screenshotInterval = null;
        }

        if (this._devToolsCheckInterval) {
            clearInterval(this._devToolsCheckInterval);
            this._devToolsCheckInterval = null;
        }

        if (this.faceCheckInterval) {
            clearInterval(this.faceCheckInterval);
            this.faceCheckInterval = null;
        }

        // Stop webcam stream
        if (this.webcamStream) {
            this.webcamStream.getTracks().forEach(track => track.stop());
            this.webcamStream = null;
        }

        // Remove webcam preview element
        const preview = document.getElementById('proctoring-webcam-preview');
        if (preview) preview.remove();

        // Remove toast container
        const toastContainer = document.getElementById('proctoring-toast-container');
        if (toastContainer) toastContainer.remove();

        // Exit fullscreen if in fullscreen
        if (document.fullscreenElement) {
            const exitFn = document.exitFullscreen ||
                           document.webkitExitFullscreen ||
                           document.mozCancelFullScreen ||
                           document.msExitFullscreen;
            if (exitFn) exitFn.call(document);
        }

        console.log('ProctoringEngine: Destroyed. Total violations:', this.violations.length);
    }

    // ========== UTILITY METHODS ==========

    /**
     * Get a summary of the proctoring session
     * @returns {object} Session summary with violation counts
     */
    getSummary() {
        const severityCounts = { low: 0, medium: 0, high: 0, critical: 0 };
        this.violations.forEach(v => {
            if (severityCounts[v.severity] !== undefined) {
                severityCounts[v.severity]++;
            }
        });

        return {
            sessionId: this.sessionId,
            isActive: this.isActive,
            totalViolations: this.violations.length,
            warningCount: this.warningCount,
            tabSwitchCount: this.tabSwitchCount,
            severityCounts: severityCounts,
            violations: [...this.violations]
        };
    }

    /**
     * Check if proctoring is currently active
     * @returns {boolean}
     */
    isRunning() {
        return this.isActive;
    }

    /**
     * Get the current violation count
     * @returns {number}
     */
    getViolationCount() {
        return this.violations.length;
    }

    /**
     * Get the current warning count
     * @returns {number}
     */
    getWarningCount() {
        return this.warningCount;
    }
}

// Export for global use
window.ProctoringEngine = ProctoringEngine;
