PWA Icons - Add PNG files here for best install experience.
Required: icon-72.png, icon-96.png, icon-128.png, icon-144.png, icon-152.png, icon-192.png, icon-384.png, icon-512.png
If missing, the app uses logo.png as fallback (manifest includes it).
Generate from logo.png: https://www.pwabuilder.com/imageGenerator

Deployment: On each production deploy, bump CACHE_VERSION in wwwroot/sw.js.
Full checklist: see docs/PWA-DEPLOYMENT.md in the project root.
